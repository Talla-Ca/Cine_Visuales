﻿namespace GestorSalas.Vistas
{
    partial class AdministradorPeliculas
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
			this.gesPeliculaBtn = new System.Windows.Forms.Button();
			this.btnModificar = new System.Windows.Forms.Button();
			this.btnEliminarPelicula = new System.Windows.Forms.Button();
			this.dgvPelicula = new System.Windows.Forms.DataGridView();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.btn_atras_peliculas = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dgvPelicula)).BeginInit();
			this.tableLayoutPanel1.SuspendLayout();
			this.tableLayoutPanel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// gesPeliculaBtn
			// 
			this.gesPeliculaBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.gesPeliculaBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(167)))), ((int)(((byte)(69)))));
			this.gesPeliculaBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.gesPeliculaBtn.FlatAppearance.BorderSize = 0;
			this.gesPeliculaBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.gesPeliculaBtn.Font = new System.Drawing.Font("Segoe UI Black", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.gesPeliculaBtn.ForeColor = System.Drawing.Color.Black;
			this.gesPeliculaBtn.Location = new System.Drawing.Point(11, 16);
			this.gesPeliculaBtn.Name = "gesPeliculaBtn";
			this.gesPeliculaBtn.Size = new System.Drawing.Size(150, 96);
			this.gesPeliculaBtn.TabIndex = 1;
			this.gesPeliculaBtn.Text = "Agregar Películas";
			this.gesPeliculaBtn.UseVisualStyleBackColor = false;
			this.gesPeliculaBtn.Click += new System.EventHandler(this.gesPeliculaBtn_Click);
			// 
			// btnModificar
			// 
			this.btnModificar.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.btnModificar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(123)))), ((int)(((byte)(255)))));
			this.btnModificar.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnModificar.FlatAppearance.BorderSize = 0;
			this.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnModificar.Font = new System.Drawing.Font("Segoe UI Black", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnModificar.ForeColor = System.Drawing.Color.Black;
			this.btnModificar.Location = new System.Drawing.Point(11, 134);
			this.btnModificar.Name = "btnModificar";
			this.btnModificar.Size = new System.Drawing.Size(150, 96);
			this.btnModificar.TabIndex = 2;
			this.btnModificar.Text = "Modificar Películas";
			this.btnModificar.UseVisualStyleBackColor = false;
			this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
			// 
			// btnEliminarPelicula
			// 
			this.btnEliminarPelicula.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.btnEliminarPelicula.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(53)))), ((int)(((byte)(69)))));
			this.btnEliminarPelicula.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnEliminarPelicula.FlatAppearance.BorderSize = 0;
			this.btnEliminarPelicula.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnEliminarPelicula.Font = new System.Drawing.Font("Segoe UI Black", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnEliminarPelicula.ForeColor = System.Drawing.Color.Black;
			this.btnEliminarPelicula.Location = new System.Drawing.Point(11, 252);
			this.btnEliminarPelicula.Name = "btnEliminarPelicula";
			this.btnEliminarPelicula.Size = new System.Drawing.Size(150, 96);
			this.btnEliminarPelicula.TabIndex = 3;
			this.btnEliminarPelicula.Text = "Eliminar Películas";
			this.btnEliminarPelicula.UseVisualStyleBackColor = false;
			this.btnEliminarPelicula.Click += new System.EventHandler(this.btnEliminarPelicula_Click);
			// 
			// dgvPelicula
			// 
			this.dgvPelicula.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dgvPelicula.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
			this.dgvPelicula.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(205)))), ((int)(((byte)(206)))));
			dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.Desktop;
			dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgvPelicula.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
			this.dgvPelicula.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle14.ForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle14.Padding = new System.Windows.Forms.Padding(1);
			dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(205)))), ((int)(((byte)(206)))));
			dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.Desktop;
			dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dgvPelicula.DefaultCellStyle = dataGridViewCellStyle14;
			this.dgvPelicula.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgvPelicula.Location = new System.Drawing.Point(13, 13);
			this.dgvPelicula.Name = "dgvPelicula";
			this.dgvPelicula.Size = new System.Drawing.Size(761, 518);
			this.dgvPelicula.TabIndex = 0;
			this.dgvPelicula.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPelicula_CellContentClick);
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.tableLayoutPanel1.ColumnCount = 1;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.Controls.Add(this.dgvPelicula, 0, 0);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.ForeColor = System.Drawing.Color.Black;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(10);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(10);
			this.tableLayoutPanel1.RowCount = 1;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(787, 544);
			this.tableLayoutPanel1.TabIndex = 4;
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.tableLayoutPanel2.ColumnCount = 1;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel2.Controls.Add(this.btn_atras_peliculas, 0, 3);
			this.tableLayoutPanel2.Controls.Add(this.gesPeliculaBtn, 0, 0);
			this.tableLayoutPanel2.Controls.Add(this.btnModificar, 0, 1);
			this.tableLayoutPanel2.Controls.Add(this.btnEliminarPelicula, 0, 2);
			this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Right;
			this.tableLayoutPanel2.Location = new System.Drawing.Point(615, 0);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.Padding = new System.Windows.Forms.Padding(5);
			this.tableLayoutPanel2.RowCount = 4;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.22222F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.22222F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.22222F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(172, 544);
			this.tableLayoutPanel2.TabIndex = 5;
			// 
			// btn_atras_peliculas
			// 
			this.btn_atras_peliculas.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.btn_atras_peliculas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.btn_atras_peliculas.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btn_atras_peliculas.FlatAppearance.BorderSize = 0;
			this.btn_atras_peliculas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btn_atras_peliculas.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_atras_peliculas.ForeColor = System.Drawing.Color.Black;
			this.btn_atras_peliculas.Location = new System.Drawing.Point(19, 414);
			this.btn_atras_peliculas.Name = "btn_atras_peliculas";
			this.btn_atras_peliculas.Size = new System.Drawing.Size(133, 70);
			this.btn_atras_peliculas.TabIndex = 4;
			this.btn_atras_peliculas.Text = "Cancelar";
			this.btn_atras_peliculas.UseVisualStyleBackColor = false;
			this.btn_atras_peliculas.Click += new System.EventHandler(this.btn_atras_peliculas_Click);
			// 
			// AdministradorPeliculas
			// 
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(31)))));
			this.ClientSize = new System.Drawing.Size(787, 544);
			this.Controls.Add(this.tableLayoutPanel2);
			this.Controls.Add(this.tableLayoutPanel1);
			this.Name = "AdministradorPeliculas";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Administrador de Películas";
			this.Activated += new System.EventHandler(this.AdministradorPeliculas_Activated);
			this.Load += new System.EventHandler(this.AdministradorPeliculas_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgvPelicula)).EndInit();
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel2.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button gesPeliculaBtn;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btnEliminarPelicula;
		private System.Windows.Forms.DataGridView dgvPelicula;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private System.Windows.Forms.Button btn_atras_peliculas;
	}
}
