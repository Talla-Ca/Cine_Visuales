﻿namespace GestorSalas.Vistas
{
    partial class AgregarPelicualas
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			this.nombrepTxb = new System.Windows.Forms.TextBox();
			this.NombreP = new System.Windows.Forms.Label();
			this.DuracionP = new System.Windows.Forms.Label();
			this.duracionPud = new System.Windows.Forms.NumericUpDown();
			this.agregarPbtn = new System.Windows.Forms.Button();
			this.imagenPelBtn = new System.Windows.Forms.Button();
			this.imageList1 = new System.Windows.Forms.ImageList(this.components);
			this.RutaImagenTxt = new System.Windows.Forms.TextBox();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.btn_atras_peliculas = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.duracionPud)).BeginInit();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// nombrepTxb
			// 
			this.nombrepTxb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(255)))));
			this.nombrepTxb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.nombrepTxb.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.nombrepTxb.ForeColor = System.Drawing.Color.Black;
			this.nombrepTxb.Location = new System.Drawing.Point(13, 13);
			this.nombrepTxb.Name = "nombrepTxb";
			this.nombrepTxb.Size = new System.Drawing.Size(245, 29);
			this.nombrepTxb.TabIndex = 0;
			this.nombrepTxb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// NombreP
			// 
			this.NombreP.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.NombreP.AutoSize = true;
			this.NombreP.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.NombreP.ForeColor = System.Drawing.Color.White;
			this.NombreP.Location = new System.Drawing.Point(266, 10);
			this.NombreP.Name = "NombreP";
			this.NombreP.Size = new System.Drawing.Size(121, 65);
			this.NombreP.TabIndex = 1;
			this.NombreP.Text = "Nombre";
			this.NombreP.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// DuracionP
			// 
			this.DuracionP.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.DuracionP.AutoSize = true;
			this.DuracionP.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.DuracionP.ForeColor = System.Drawing.Color.White;
			this.DuracionP.Location = new System.Drawing.Point(266, 75);
			this.DuracionP.Name = "DuracionP";
			this.DuracionP.Size = new System.Drawing.Size(121, 65);
			this.DuracionP.TabIndex = 5;
			this.DuracionP.Text = "Duración (minutos)";
			this.DuracionP.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// duracionPud
			// 
			this.duracionPud.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(255)))));
			this.duracionPud.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.duracionPud.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.duracionPud.ForeColor = System.Drawing.Color.Black;
			this.duracionPud.Location = new System.Drawing.Point(13, 78);
			this.duracionPud.Name = "duracionPud";
			this.duracionPud.Size = new System.Drawing.Size(245, 29);
			this.duracionPud.TabIndex = 2;
			this.duracionPud.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// agregarPbtn
			// 
			this.agregarPbtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.agregarPbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(167)))), ((int)(((byte)(69)))));
			this.agregarPbtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.agregarPbtn.FlatAppearance.BorderSize = 0;
			this.agregarPbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.agregarPbtn.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.agregarPbtn.ForeColor = System.Drawing.Color.Black;
			this.agregarPbtn.Location = new System.Drawing.Point(13, 208);
			this.agregarPbtn.Name = "agregarPbtn";
			this.agregarPbtn.Size = new System.Drawing.Size(247, 59);
			this.agregarPbtn.TabIndex = 5;
			this.agregarPbtn.Text = "Agregar";
			this.agregarPbtn.UseVisualStyleBackColor = false;
			this.agregarPbtn.Click += new System.EventHandler(this.agregarPbtn_Click);
			// 
			// imagenPelBtn
			// 
			this.imagenPelBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.imagenPelBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(193)))), ((int)(((byte)(7)))));
			this.imagenPelBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.imagenPelBtn.FlatAppearance.BorderSize = 0;
			this.imagenPelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.imagenPelBtn.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.imagenPelBtn.ForeColor = System.Drawing.Color.Black;
			this.imagenPelBtn.Location = new System.Drawing.Point(266, 143);
			this.imagenPelBtn.Name = "imagenPelBtn";
			this.imagenPelBtn.Size = new System.Drawing.Size(121, 59);
			this.imagenPelBtn.TabIndex = 4;
			this.imagenPelBtn.Text = "Importar imagen";
			this.imagenPelBtn.UseVisualStyleBackColor = false;
			this.imagenPelBtn.Click += new System.EventHandler(this.imagenPelBtn_Click);
			// 
			// imageList1
			// 
			this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
			this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// RutaImagenTxt
			// 
			this.RutaImagenTxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(255)))));
			this.RutaImagenTxt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.RutaImagenTxt.ForeColor = System.Drawing.Color.Black;
			this.RutaImagenTxt.Location = new System.Drawing.Point(13, 143);
			this.RutaImagenTxt.Name = "RutaImagenTxt";
			this.RutaImagenTxt.ReadOnly = true;
			this.RutaImagenTxt.Size = new System.Drawing.Size(245, 29);
			this.RutaImagenTxt.TabIndex = 3;
			this.RutaImagenTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(17)))), ((int)(((byte)(43)))));
			this.tableLayoutPanel1.ColumnCount = 2;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 66.66666F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel1.Controls.Add(this.agregarPbtn, 0, 3);
			this.tableLayoutPanel1.Controls.Add(this.imagenPelBtn, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this.nombrepTxb, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.duracionPud, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.DuracionP, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.NombreP, 1, 0);
			this.tableLayoutPanel1.Controls.Add(this.RutaImagenTxt, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.btn_atras_peliculas, 1, 3);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(10);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(10);
			this.tableLayoutPanel1.RowCount = 4;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(400, 280);
			this.tableLayoutPanel1.TabIndex = 11;
			this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
			// 
			// btn_atras_peliculas
			// 
			this.btn_atras_peliculas.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.btn_atras_peliculas.BackColor = System.Drawing.Color.Red;
			this.btn_atras_peliculas.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btn_atras_peliculas.FlatAppearance.BorderSize = 0;
			this.btn_atras_peliculas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_atras_peliculas.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_atras_peliculas.ForeColor = System.Drawing.Color.Black;
			this.btn_atras_peliculas.Location = new System.Drawing.Point(266, 208);
			this.btn_atras_peliculas.Name = "btn_atras_peliculas";
			this.btn_atras_peliculas.Size = new System.Drawing.Size(121, 59);
			this.btn_atras_peliculas.TabIndex = 6;
			this.btn_atras_peliculas.Text = "Cancelar";
			this.btn_atras_peliculas.UseVisualStyleBackColor = false;
			this.btn_atras_peliculas.Click += new System.EventHandler(this.btn_atras_peliculas_Click);
			// 
			// AgregarPelicualas
			// 
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(31)))));
			this.ClientSize = new System.Drawing.Size(400, 280);
			this.Controls.Add(this.tableLayoutPanel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "AgregarPelicualas";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Agregar Películas";
			this.Activated += new System.EventHandler(this.AgregarPelicualas_Activated);
			this.Load += new System.EventHandler(this.AgregarPelicualas_Load);
			((System.ComponentModel.ISupportInitialize)(this.duracionPud)).EndInit();
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox nombrepTxb;
        private System.Windows.Forms.Label NombreP;
        private System.Windows.Forms.Label DuracionP;
        private System.Windows.Forms.NumericUpDown duracionPud;
        private System.Windows.Forms.Button agregarPbtn;
        private System.Windows.Forms.Button imagenPelBtn;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TextBox RutaImagenTxt;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.Button btn_atras_peliculas;
	}
}
