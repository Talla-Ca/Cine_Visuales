﻿using GestorSalas.Modelos;
using GestorSalas.Servicios;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace GestorSalas.Vistas
{
    public partial class VentaDulces : Form
    {


        public VentaDulces(Venta venta)
        {

            InitializeComponent();

        }

		private void pictureBox1_Click(object sender, EventArgs e)
		{

		}

		private void pictureBox9_Click(object sender, EventArgs e)
		{

		}

		private void label21_Click(object sender, EventArgs e)
		{

		}

		private void label12_Click(object sender, EventArgs e)
		{

		}

		private void volverBtn_Click(object sender, EventArgs e)
		{
            this.Close();
		}
	}
}
