﻿namespace GestorSalas
{
    partial class Peliculas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.btnCambiarUsuario = new System.Windows.Forms.Button();
			this.gestionarBaseBtn = new System.Windows.Forms.Button();
			this.ComprarDulcesbtn = new System.Windows.Forms.Button();
			this.btn_atras_peliculas = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnCambiarUsuario
			// 
			this.btnCambiarUsuario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(205)))), ((int)(((byte)(206)))));
			this.btnCambiarUsuario.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnCambiarUsuario.FlatAppearance.BorderSize = 0;
			this.btnCambiarUsuario.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnCambiarUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnCambiarUsuario.ForeColor = System.Drawing.Color.Black;
			this.btnCambiarUsuario.Location = new System.Drawing.Point(503, 184);
			this.btnCambiarUsuario.Name = "btnCambiarUsuario";
			this.btnCambiarUsuario.Size = new System.Drawing.Size(194, 135);
			this.btnCambiarUsuario.TabIndex = 1;
			this.btnCambiarUsuario.Text = "Cambiar Usuario";
			this.btnCambiarUsuario.UseVisualStyleBackColor = false;
			this.btnCambiarUsuario.Click += new System.EventHandler(this.btnCambiarUsuario_Click);
			// 
			// gestionarBaseBtn
			// 
			this.gestionarBaseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(193)))), ((int)(((byte)(7)))));
			this.gestionarBaseBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.gestionarBaseBtn.FlatAppearance.BorderSize = 0;
			this.gestionarBaseBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.gestionarBaseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.gestionarBaseBtn.ForeColor = System.Drawing.Color.Black;
			this.gestionarBaseBtn.Location = new System.Drawing.Point(503, 352);
			this.gestionarBaseBtn.Name = "gestionarBaseBtn";
			this.gestionarBaseBtn.Size = new System.Drawing.Size(194, 135);
			this.gestionarBaseBtn.TabIndex = 3;
			this.gestionarBaseBtn.Text = "Gestionar Base";
			this.gestionarBaseBtn.UseVisualStyleBackColor = false;
			this.gestionarBaseBtn.Click += new System.EventHandler(this.gestionarBaseBtn_Click);
			// 
			// ComprarDulcesbtn
			// 
			this.ComprarDulcesbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.ComprarDulcesbtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.ComprarDulcesbtn.FlatAppearance.BorderSize = 0;
			this.ComprarDulcesbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.ComprarDulcesbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ComprarDulcesbtn.ForeColor = System.Drawing.Color.Black;
			this.ComprarDulcesbtn.Location = new System.Drawing.Point(503, 19);
			this.ComprarDulcesbtn.Name = "ComprarDulcesbtn";
			this.ComprarDulcesbtn.Size = new System.Drawing.Size(194, 135);
			this.ComprarDulcesbtn.TabIndex = 4;
			this.ComprarDulcesbtn.Text = "Comprar Alimentos";
			this.ComprarDulcesbtn.UseVisualStyleBackColor = false;
			this.ComprarDulcesbtn.Click += new System.EventHandler(this.ComprarDulcesbtn_Click);
			// 
			// btn_atras_peliculas
			// 
			this.btn_atras_peliculas.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.btn_atras_peliculas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.btn_atras_peliculas.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btn_atras_peliculas.FlatAppearance.BorderSize = 0;
			this.btn_atras_peliculas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btn_atras_peliculas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_atras_peliculas.ForeColor = System.Drawing.Color.Black;
			this.btn_atras_peliculas.Location = new System.Drawing.Point(535, 510);
			this.btn_atras_peliculas.Name = "btn_atras_peliculas";
			this.btn_atras_peliculas.Size = new System.Drawing.Size(133, 70);
			this.btn_atras_peliculas.TabIndex = 5;
			this.btn_atras_peliculas.Text = "Salir";
			this.btn_atras_peliculas.UseVisualStyleBackColor = false;
			this.btn_atras_peliculas.Click += new System.EventHandler(this.btn_atras_peliculas_Click);
			// 
			// Peliculas
			// 
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.ClientSize = new System.Drawing.Size(726, 601);
			this.Controls.Add(this.btn_atras_peliculas);
			this.Controls.Add(this.ComprarDulcesbtn);
			this.Controls.Add(this.btnCambiarUsuario);
			this.Controls.Add(this.gestionarBaseBtn);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "Peliculas";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Gestión de Películas";
			this.Activated += new System.EventHandler(this.Peliculas_Activated_1);
			this.Load += new System.EventHandler(this.Peliculas_Load_1);
			this.ResumeLayout(false);

        }


        #endregion

        private System.Windows.Forms.Button btnCambiarUsuario;
        private System.Windows.Forms.Button gestionarBaseBtn;
        private System.Windows.Forms.Button ComprarDulcesbtn;
		private System.Windows.Forms.Button btn_atras_peliculas;
	}
}