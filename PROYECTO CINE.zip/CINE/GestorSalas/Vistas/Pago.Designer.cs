﻿namespace GestorSalas.Vistas
{
    partial class Pago
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
			this.CambioBtn = new System.Windows.Forms.Button();
			this.TipoPagoCb = new System.Windows.Forms.ComboBox();
			this.TipoPago = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.Pagotxt = new System.Windows.Forms.TextBox();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.label_boletos_total = new System.Windows.Forms.Label();
			this.btn_atras_peliculas = new System.Windows.Forms.Button();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// CambioBtn
			// 
			this.CambioBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
			this.CambioBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(205)))), ((int)(((byte)(206)))));
			this.CambioBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.CambioBtn.FlatAppearance.BorderSize = 0;
			this.CambioBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.CambioBtn.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CambioBtn.ForeColor = System.Drawing.Color.Black;
			this.CambioBtn.Location = new System.Drawing.Point(150, 308);
			this.CambioBtn.Name = "CambioBtn";
			this.CambioBtn.Size = new System.Drawing.Size(155, 53);
			this.CambioBtn.TabIndex = 3;
			this.CambioBtn.Text = "Cobrar";
			this.CambioBtn.UseVisualStyleBackColor = false;
			this.CambioBtn.Click += new System.EventHandler(this.CambioBtn_Click);
			// 
			// TipoPagoCb
			// 
			this.TipoPagoCb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
			this.TipoPagoCb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(255)))));
			this.TipoPagoCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.TipoPagoCb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.TipoPagoCb.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.TipoPagoCb.ForeColor = System.Drawing.Color.Black;
			this.TipoPagoCb.Location = new System.Drawing.Point(138, 137);
			this.TipoPagoCb.Name = "TipoPagoCb";
			this.TipoPagoCb.Size = new System.Drawing.Size(180, 29);
			this.TipoPagoCb.TabIndex = 1;
			// 
			// TipoPago
			// 
			this.TipoPago.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
			this.TipoPago.AutoSize = true;
			this.TipoPago.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.TipoPago.ForeColor = System.Drawing.Color.White;
			this.TipoPago.Location = new System.Drawing.Point(189, 77);
			this.TipoPago.Name = "TipoPago";
			this.TipoPago.Size = new System.Drawing.Size(78, 57);
			this.TipoPago.TabIndex = 2;
			this.TipoPago.Text = "Tipo Pago";
			this.TipoPago.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label2.ForeColor = System.Drawing.Color.White;
			this.label2.Location = new System.Drawing.Point(206, 191);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(44, 57);
			this.label2.TabIndex = 3;
			this.label2.Text = "Pago";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Pagotxt
			// 
			this.Pagotxt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
			this.Pagotxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(255)))));
			this.Pagotxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Pagotxt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Pagotxt.ForeColor = System.Drawing.Color.Black;
			this.Pagotxt.Location = new System.Drawing.Point(141, 251);
			this.Pagotxt.Name = "Pagotxt";
			this.Pagotxt.Size = new System.Drawing.Size(173, 29);
			this.Pagotxt.TabIndex = 2;
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.tableLayoutPanel1.ColumnCount = 3;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.61159F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 84.38842F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
			this.tableLayoutPanel1.Controls.Add(this.TipoPago, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this.label2, 1, 4);
			this.tableLayoutPanel1.Controls.Add(this.Pagotxt, 1, 5);
			this.tableLayoutPanel1.Controls.Add(this.label_boletos_total, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.btn_atras_peliculas, 2, 6);
			this.tableLayoutPanel1.Controls.Add(this.CambioBtn, 1, 6);
			this.tableLayoutPanel1.Controls.Add(this.TipoPagoCb, 1, 3);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 7;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(494, 364);
			this.tableLayoutPanel1.TabIndex = 5;
			// 
			// label_boletos_total
			// 
			this.label_boletos_total.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
			this.label_boletos_total.AutoSize = true;
			this.label_boletos_total.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.label_boletos_total.ForeColor = System.Drawing.Color.White;
			this.label_boletos_total.Location = new System.Drawing.Point(178, 20);
			this.label_boletos_total.Name = "label_boletos_total";
			this.label_boletos_total.Size = new System.Drawing.Size(99, 57);
			this.label_boletos_total.TabIndex = 5;
			this.label_boletos_total.Text = "info del pago";
			this.label_boletos_total.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btn_atras_peliculas
			// 
			this.btn_atras_peliculas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.btn_atras_peliculas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.btn_atras_peliculas.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btn_atras_peliculas.FlatAppearance.BorderSize = 0;
			this.btn_atras_peliculas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btn_atras_peliculas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_atras_peliculas.ForeColor = System.Drawing.Color.Black;
			this.btn_atras_peliculas.Location = new System.Drawing.Point(398, 308);
			this.btn_atras_peliculas.Name = "btn_atras_peliculas";
			this.btn_atras_peliculas.Size = new System.Drawing.Size(93, 53);
			this.btn_atras_peliculas.TabIndex = 4;
			this.btn_atras_peliculas.Text = "Cancelar";
			this.btn_atras_peliculas.UseVisualStyleBackColor = false;
			this.btn_atras_peliculas.Click += new System.EventHandler(this.btn_atras_peliculas_Click);
			// 
			// Pago
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(31)))));
			this.ClientSize = new System.Drawing.Size(494, 364);
			this.Controls.Add(this.tableLayoutPanel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "Pago";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Cambio";
			this.Load += new System.EventHandler(this.Cambio_Load);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button CambioBtn;
        private System.Windows.Forms.ComboBox TipoPagoCb;
        private System.Windows.Forms.Label TipoPago;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Pagotxt;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.Label label_boletos_total;
		private System.Windows.Forms.Button btn_atras_peliculas;
	}
}
