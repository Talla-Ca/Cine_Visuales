﻿namespace GestorSalas.Vistas
{
    partial class EmpleadoFrm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
			this.nombreEmtxt = new System.Windows.Forms.TextBox();
			this.nombreEmlbl = new System.Windows.Forms.Label();
			this.puestoEmlbl = new System.Windows.Forms.Label();
			this.usuarioEmlbl = new System.Windows.Forms.Label();
			this.usuarioEmtxt = new System.Windows.Forms.TextBox();
			this.puestoEmcbx = new System.Windows.Forms.ComboBox();
			this.contraseñaEmlbl = new System.Windows.Forms.Label();
			this.contraseñaEmtxt = new System.Windows.Forms.TextBox();
			this.cargarEmpleado = new System.Windows.Forms.Button();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.btn_atras_peliculas = new System.Windows.Forms.Button();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// nombreEmtxt
			// 
			this.nombreEmtxt.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.nombreEmtxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(255)))));
			this.nombreEmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.nombreEmtxt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.nombreEmtxt.ForeColor = System.Drawing.Color.Black;
			this.nombreEmtxt.Location = new System.Drawing.Point(44, 25);
			this.nombreEmtxt.Name = "nombreEmtxt";
			this.nombreEmtxt.Size = new System.Drawing.Size(156, 25);
			this.nombreEmtxt.TabIndex = 0;
			this.nombreEmtxt.TextChanged += new System.EventHandler(this.nombreEmtxt_TextChanged);
			// 
			// nombreEmlbl
			// 
			this.nombreEmlbl.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.nombreEmlbl.AutoSize = true;
			this.nombreEmlbl.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.nombreEmlbl.ForeColor = System.Drawing.Color.White;
			this.nombreEmlbl.Location = new System.Drawing.Point(216, 19);
			this.nombreEmlbl.Name = "nombreEmlbl";
			this.nombreEmlbl.Size = new System.Drawing.Size(94, 38);
			this.nombreEmlbl.TabIndex = 1;
			this.nombreEmlbl.Text = "Nombre del empleado";
			// 
			// puestoEmlbl
			// 
			this.puestoEmlbl.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.puestoEmlbl.AutoSize = true;
			this.puestoEmlbl.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.puestoEmlbl.ForeColor = System.Drawing.Color.White;
			this.puestoEmlbl.Location = new System.Drawing.Point(216, 104);
			this.puestoEmlbl.Name = "puestoEmlbl";
			this.puestoEmlbl.Size = new System.Drawing.Size(54, 19);
			this.puestoEmlbl.TabIndex = 3;
			this.puestoEmlbl.Text = "Puesto";
			// 
			// usuarioEmlbl
			// 
			this.usuarioEmlbl.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.usuarioEmlbl.AutoSize = true;
			this.usuarioEmlbl.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.usuarioEmlbl.ForeColor = System.Drawing.Color.White;
			this.usuarioEmlbl.Location = new System.Drawing.Point(216, 180);
			this.usuarioEmlbl.Name = "usuarioEmlbl";
			this.usuarioEmlbl.Size = new System.Drawing.Size(60, 19);
			this.usuarioEmlbl.TabIndex = 7;
			this.usuarioEmlbl.Text = "Usuario";
			// 
			// usuarioEmtxt
			// 
			this.usuarioEmtxt.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.usuarioEmtxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(255)))));
			this.usuarioEmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.usuarioEmtxt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.usuarioEmtxt.ForeColor = System.Drawing.Color.Black;
			this.usuarioEmtxt.Location = new System.Drawing.Point(44, 177);
			this.usuarioEmtxt.Name = "usuarioEmtxt";
			this.usuarioEmtxt.Size = new System.Drawing.Size(156, 25);
			this.usuarioEmtxt.TabIndex = 3;
			// 
			// puestoEmcbx
			// 
			this.puestoEmcbx.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.puestoEmcbx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(255)))));
			this.puestoEmcbx.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.puestoEmcbx.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.puestoEmcbx.ForeColor = System.Drawing.Color.Black;
			this.puestoEmcbx.FormattingEnabled = true;
			this.puestoEmcbx.Location = new System.Drawing.Point(44, 101);
			this.puestoEmcbx.Name = "puestoEmcbx";
			this.puestoEmcbx.Size = new System.Drawing.Size(156, 25);
			this.puestoEmcbx.TabIndex = 2;
			this.puestoEmcbx.SelectedIndexChanged += new System.EventHandler(this.puestoEmcbx_SelectedIndexChanged);
			// 
			// contraseñaEmlbl
			// 
			this.contraseñaEmlbl.Anchor = System.Windows.Forms.AnchorStyles.Left;
			this.contraseñaEmlbl.AutoSize = true;
			this.contraseñaEmlbl.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
			this.contraseñaEmlbl.ForeColor = System.Drawing.Color.White;
			this.contraseñaEmlbl.Location = new System.Drawing.Point(216, 256);
			this.contraseñaEmlbl.Name = "contraseñaEmlbl";
			this.contraseñaEmlbl.Size = new System.Drawing.Size(84, 19);
			this.contraseñaEmlbl.TabIndex = 10;
			this.contraseñaEmlbl.Text = "Contraseña";
			// 
			// contraseñaEmtxt
			// 
			this.contraseñaEmtxt.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.contraseñaEmtxt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(255)))));
			this.contraseñaEmtxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.contraseñaEmtxt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.contraseñaEmtxt.ForeColor = System.Drawing.Color.Black;
			this.contraseñaEmtxt.Location = new System.Drawing.Point(44, 253);
			this.contraseñaEmtxt.Name = "contraseñaEmtxt";
			this.contraseñaEmtxt.Size = new System.Drawing.Size(156, 25);
			this.contraseñaEmtxt.TabIndex = 4;
			// 
			// cargarEmpleado
			// 
			this.cargarEmpleado.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.cargarEmpleado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(205)))), ((int)(((byte)(206)))));
			this.cargarEmpleado.Cursor = System.Windows.Forms.Cursors.Hand;
			this.cargarEmpleado.FlatAppearance.BorderSize = 0;
			this.cargarEmpleado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cargarEmpleado.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cargarEmpleado.ForeColor = System.Drawing.Color.Black;
			this.cargarEmpleado.Location = new System.Drawing.Point(94, 319);
			this.cargarEmpleado.Name = "cargarEmpleado";
			this.cargarEmpleado.Size = new System.Drawing.Size(116, 50);
			this.cargarEmpleado.TabIndex = 5;
			this.cargarEmpleado.Text = "Cargar Datos";
			this.cargarEmpleado.UseVisualStyleBackColor = false;
			this.cargarEmpleado.Click += new System.EventHandler(this.cargarEmpleado_Click);
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.tableLayoutPanel1.ColumnCount = 3;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 57.91139F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.27848F));
			this.tableLayoutPanel1.Controls.Add(this.contraseñaEmtxt, 1, 3);
			this.tableLayoutPanel1.Controls.Add(this.puestoEmcbx, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.usuarioEmtxt, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this.nombreEmlbl, 2, 0);
			this.tableLayoutPanel1.Controls.Add(this.puestoEmlbl, 2, 1);
			this.tableLayoutPanel1.Controls.Add(this.usuarioEmlbl, 2, 2);
			this.tableLayoutPanel1.Controls.Add(this.contraseñaEmlbl, 2, 3);
			this.tableLayoutPanel1.Controls.Add(this.nombreEmtxt, 1, 0);
			this.tableLayoutPanel1.Controls.Add(this.cargarEmpleado, 1, 4);
			this.tableLayoutPanel1.Controls.Add(this.btn_atras_peliculas, 2, 4);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 5;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(316, 384);
			this.tableLayoutPanel1.TabIndex = 12;
			// 
			// btn_atras_peliculas
			// 
			this.btn_atras_peliculas.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.btn_atras_peliculas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.btn_atras_peliculas.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btn_atras_peliculas.FlatAppearance.BorderSize = 0;
			this.btn_atras_peliculas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btn_atras_peliculas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_atras_peliculas.ForeColor = System.Drawing.Color.Black;
			this.btn_atras_peliculas.Location = new System.Drawing.Point(222, 326);
			this.btn_atras_peliculas.Name = "btn_atras_peliculas";
			this.btn_atras_peliculas.Size = new System.Drawing.Size(85, 35);
			this.btn_atras_peliculas.TabIndex = 6;
			this.btn_atras_peliculas.Text = "Cancelar";
			this.btn_atras_peliculas.UseVisualStyleBackColor = false;
			// 
			// EmpleadoFrm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(31)))));
			this.ClientSize = new System.Drawing.Size(316, 384);
			this.Controls.Add(this.tableLayoutPanel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "EmpleadoFrm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Empleado";
			this.Load += new System.EventHandler(this.EmpleadoFrm_Load);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox nombreEmtxt;
        private System.Windows.Forms.Label nombreEmlbl;
        private System.Windows.Forms.Label puestoEmlbl;
        private System.Windows.Forms.Label usuarioEmlbl;
        private System.Windows.Forms.TextBox usuarioEmtxt;
        private System.Windows.Forms.ComboBox puestoEmcbx;
        private System.Windows.Forms.Label contraseñaEmlbl;
        private System.Windows.Forms.TextBox contraseñaEmtxt;
        private System.Windows.Forms.Button cargarEmpleado;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.Button btn_atras_peliculas;
	}
}
