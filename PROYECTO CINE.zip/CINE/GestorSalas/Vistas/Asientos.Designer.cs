﻿namespace GestorSalas
{
    partial class frmAsientos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.A1 = new System.Windows.Forms.Button();
			this.B3 = new System.Windows.Forms.Button();
			this.B2 = new System.Windows.Forms.Button();
			this.B1 = new System.Windows.Forms.Button();
			this.A3 = new System.Windows.Forms.Button();
			this.A2 = new System.Windows.Forms.Button();
			this.C1 = new System.Windows.Forms.Button();
			this.C2 = new System.Windows.Forms.Button();
			this.C3 = new System.Windows.Forms.Button();
			this.lblA = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.btnBuscarAsiento = new System.Windows.Forms.Button();
			this.A4 = new System.Windows.Forms.Button();
			this.B4 = new System.Windows.Forms.Button();
			this.C4 = new System.Windows.Forms.Button();
			this.btn_atras_peliculas = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// A1
			// 
			this.A1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.A1.Location = new System.Drawing.Point(120, 77);
			this.A1.Name = "A1";
			this.A1.Size = new System.Drawing.Size(44, 38);
			this.A1.TabIndex = 0;
			this.A1.Text = "1";
			this.A1.UseVisualStyleBackColor = true;
			// 
			// B3
			// 
			this.B3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.B3.Location = new System.Drawing.Point(249, 136);
			this.B3.Name = "B3";
			this.B3.Size = new System.Drawing.Size(44, 38);
			this.B3.TabIndex = 7;
			this.B3.Text = "3";
			this.B3.UseVisualStyleBackColor = true;
			// 
			// B2
			// 
			this.B2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.B2.Location = new System.Drawing.Point(184, 136);
			this.B2.Name = "B2";
			this.B2.Size = new System.Drawing.Size(44, 38);
			this.B2.TabIndex = 6;
			this.B2.Text = "2";
			this.B2.UseVisualStyleBackColor = true;
			// 
			// B1
			// 
			this.B1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.B1.Location = new System.Drawing.Point(120, 136);
			this.B1.Name = "B1";
			this.B1.Size = new System.Drawing.Size(44, 38);
			this.B1.TabIndex = 5;
			this.B1.Text = "1";
			this.B1.UseVisualStyleBackColor = true;
			// 
			// A3
			// 
			this.A3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.A3.Location = new System.Drawing.Point(249, 77);
			this.A3.Name = "A3";
			this.A3.Size = new System.Drawing.Size(44, 38);
			this.A3.TabIndex = 5;
			this.A3.Text = "3";
			this.A3.UseVisualStyleBackColor = true;
			// 
			// A2
			// 
			this.A2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.A2.Location = new System.Drawing.Point(184, 77);
			this.A2.Name = "A2";
			this.A2.Size = new System.Drawing.Size(44, 38);
			this.A2.TabIndex = 6;
			this.A2.Text = "2";
			this.A2.UseVisualStyleBackColor = true;
			// 
			// C1
			// 
			this.C1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.C1.Location = new System.Drawing.Point(120, 195);
			this.C1.Name = "C1";
			this.C1.Size = new System.Drawing.Size(44, 38);
			this.C1.TabIndex = 9;
			this.C1.Text = "1";
			this.C1.UseVisualStyleBackColor = true;
			// 
			// C2
			// 
			this.C2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.C2.Location = new System.Drawing.Point(184, 195);
			this.C2.Name = "C2";
			this.C2.Size = new System.Drawing.Size(44, 38);
			this.C2.TabIndex = 10;
			this.C2.Text = "2";
			this.C2.UseVisualStyleBackColor = true;
			// 
			// C3
			// 
			this.C3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.C3.Location = new System.Drawing.Point(249, 195);
			this.C3.Name = "C3";
			this.C3.Size = new System.Drawing.Size(44, 38);
			this.C3.TabIndex = 11;
			this.C3.Text = "3";
			this.C3.UseVisualStyleBackColor = true;
			// 
			// lblA
			// 
			this.lblA.AutoSize = true;
			this.lblA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblA.ForeColor = System.Drawing.Color.White;
			this.lblA.Location = new System.Drawing.Point(48, 82);
			this.lblA.Name = "lblA";
			this.lblA.Size = new System.Drawing.Size(23, 24);
			this.lblA.TabIndex = 12;
			this.lblA.Text = "A";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(48, 141);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(22, 24);
			this.label1.TabIndex = 13;
			this.label1.Text = "B";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.White;
			this.label2.Location = new System.Drawing.Point(48, 200);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(23, 24);
			this.label2.TabIndex = 14;
			this.label2.Text = "C";
			// 
			// btnBuscarAsiento
			// 
			this.btnBuscarAsiento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(205)))), ((int)(((byte)(206)))));
			this.btnBuscarAsiento.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btnBuscarAsiento.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btnBuscarAsiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnBuscarAsiento.ForeColor = System.Drawing.Color.Black;
			this.btnBuscarAsiento.Location = new System.Drawing.Point(184, 278);
			this.btnBuscarAsiento.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnBuscarAsiento.Name = "btnBuscarAsiento";
			this.btnBuscarAsiento.Size = new System.Drawing.Size(133, 56);
			this.btnBuscarAsiento.TabIndex = 13;
			this.btnBuscarAsiento.Text = "Continuar";
			this.btnBuscarAsiento.UseVisualStyleBackColor = false;
			this.btnBuscarAsiento.Click += new System.EventHandler(this.btnBuscarAsiento_Click);
			this.btnBuscarAsiento.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnBuscarAsiento_MouseClick);
			// 
			// A4
			// 
			this.A4.Cursor = System.Windows.Forms.Cursors.Hand;
			this.A4.Location = new System.Drawing.Point(312, 77);
			this.A4.Name = "A4";
			this.A4.Size = new System.Drawing.Size(44, 38);
			this.A4.TabIndex = 4;
			this.A4.Text = "4";
			this.A4.UseVisualStyleBackColor = true;
			// 
			// B4
			// 
			this.B4.Cursor = System.Windows.Forms.Cursors.Hand;
			this.B4.Location = new System.Drawing.Point(312, 136);
			this.B4.Name = "B4";
			this.B4.Size = new System.Drawing.Size(44, 38);
			this.B4.TabIndex = 8;
			this.B4.Text = "4";
			this.B4.UseVisualStyleBackColor = true;
			// 
			// C4
			// 
			this.C4.Cursor = System.Windows.Forms.Cursors.Hand;
			this.C4.Location = new System.Drawing.Point(312, 195);
			this.C4.Name = "C4";
			this.C4.Size = new System.Drawing.Size(44, 38);
			this.C4.TabIndex = 12;
			this.C4.Text = "4";
			this.C4.UseVisualStyleBackColor = true;
			this.C4.Click += new System.EventHandler(this.C4_Click);
			// 
			// btn_atras_peliculas
			// 
			this.btn_atras_peliculas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.btn_atras_peliculas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.btn_atras_peliculas.Cursor = System.Windows.Forms.Cursors.Hand;
			this.btn_atras_peliculas.FlatAppearance.BorderSize = 0;
			this.btn_atras_peliculas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
			this.btn_atras_peliculas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_atras_peliculas.ForeColor = System.Drawing.Color.Black;
			this.btn_atras_peliculas.Location = new System.Drawing.Point(363, 340);
			this.btn_atras_peliculas.Name = "btn_atras_peliculas";
			this.btn_atras_peliculas.Size = new System.Drawing.Size(102, 39);
			this.btn_atras_peliculas.TabIndex = 14;
			this.btn_atras_peliculas.Text = "Cancelar";
			this.btn_atras_peliculas.UseVisualStyleBackColor = false;
			this.btn_atras_peliculas.Click += new System.EventHandler(this.btn_atras_peliculas_Click);
			// 
			// frmAsientos
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.ClientSize = new System.Drawing.Size(477, 391);
			this.Controls.Add(this.btn_atras_peliculas);
			this.Controls.Add(this.btnBuscarAsiento);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.lblA);
			this.Controls.Add(this.C4);
			this.Controls.Add(this.C3);
			this.Controls.Add(this.C2);
			this.Controls.Add(this.C1);
			this.Controls.Add(this.B4);
			this.Controls.Add(this.A2);
			this.Controls.Add(this.A3);
			this.Controls.Add(this.A4);
			this.Controls.Add(this.B1);
			this.Controls.Add(this.B2);
			this.Controls.Add(this.B3);
			this.Controls.Add(this.A1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "frmAsientos";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Asientos";
			this.Load += new System.EventHandler(this.Asientos_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button A1;
        private System.Windows.Forms.Button B3;
        private System.Windows.Forms.Button B2;
        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.Button A3;
        private System.Windows.Forms.Button A2;
        private System.Windows.Forms.Button C1;
        private System.Windows.Forms.Button C2;
        private System.Windows.Forms.Button C3;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBuscarAsiento;
		private System.Windows.Forms.Button C4;
		private System.Windows.Forms.Button B4;
		private System.Windows.Forms.Button A4;
		private System.Windows.Forms.Button btn_atras_peliculas;
	}
}