﻿namespace GestorSalas.Vistas
{
    partial class GestionarEmpleados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			this.eliminarEmpBtn = new System.Windows.Forms.Button();
			this.modificarEmpBtn = new System.Windows.Forms.Button();
			this.empleadoDgv = new System.Windows.Forms.DataGridView();
			this.agregarEmbtn = new System.Windows.Forms.Button();
			this.volverBtn = new System.Windows.Forms.Button();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			((System.ComponentModel.ISupportInitialize)(this.empleadoDgv)).BeginInit();
			this.tableLayoutPanel1.SuspendLayout();
			this.tableLayoutPanel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// eliminarEmpBtn
			// 
			this.eliminarEmpBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.eliminarEmpBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(53)))), ((int)(((byte)(69)))));
			this.eliminarEmpBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.eliminarEmpBtn.FlatAppearance.BorderSize = 0;
			this.eliminarEmpBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.eliminarEmpBtn.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.eliminarEmpBtn.ForeColor = System.Drawing.Color.Black;
			this.eliminarEmpBtn.Location = new System.Drawing.Point(19, 284);
			this.eliminarEmpBtn.Name = "eliminarEmpBtn";
			this.eliminarEmpBtn.Size = new System.Drawing.Size(161, 81);
			this.eliminarEmpBtn.TabIndex = 3;
			this.eliminarEmpBtn.Text = "Eliminar Empleado";
			this.eliminarEmpBtn.UseVisualStyleBackColor = false;
			this.eliminarEmpBtn.Click += new System.EventHandler(this.eliminarEmpBtn_Click);
			// 
			// modificarEmpBtn
			// 
			this.modificarEmpBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.modificarEmpBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(123)))), ((int)(((byte)(255)))));
			this.modificarEmpBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.modificarEmpBtn.FlatAppearance.BorderSize = 0;
			this.modificarEmpBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.modificarEmpBtn.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.modificarEmpBtn.ForeColor = System.Drawing.Color.Black;
			this.modificarEmpBtn.Location = new System.Drawing.Point(19, 154);
			this.modificarEmpBtn.Name = "modificarEmpBtn";
			this.modificarEmpBtn.Size = new System.Drawing.Size(161, 81);
			this.modificarEmpBtn.TabIndex = 2;
			this.modificarEmpBtn.Text = "Modificar Empleado";
			this.modificarEmpBtn.UseVisualStyleBackColor = false;
			this.modificarEmpBtn.Click += new System.EventHandler(this.modificarEmpBtn_Click);
			// 
			// empleadoDgv
			// 
			this.empleadoDgv.AllowUserToAddRows = false;
			this.empleadoDgv.AllowUserToDeleteRows = false;
			this.empleadoDgv.AllowUserToResizeColumns = false;
			this.empleadoDgv.AllowUserToResizeRows = false;
			this.empleadoDgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.empleadoDgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.empleadoDgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
			this.empleadoDgv.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(205)))), ((int)(((byte)(206)))));
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.Desktop;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.empleadoDgv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.empleadoDgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(206)))), ((int)(((byte)(206)))));
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.empleadoDgv.DefaultCellStyle = dataGridViewCellStyle2;
			this.empleadoDgv.Location = new System.Drawing.Point(3, 3);
			this.empleadoDgv.Name = "empleadoDgv";
			this.empleadoDgv.ReadOnly = true;
			this.empleadoDgv.Size = new System.Drawing.Size(638, 515);
			this.empleadoDgv.TabIndex = 5;
			// 
			// agregarEmbtn
			// 
			this.agregarEmbtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.agregarEmbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(167)))), ((int)(((byte)(69)))));
			this.agregarEmbtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.agregarEmbtn.FlatAppearance.BorderSize = 0;
			this.agregarEmbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.agregarEmbtn.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.agregarEmbtn.ForeColor = System.Drawing.Color.Black;
			this.agregarEmbtn.Location = new System.Drawing.Point(19, 24);
			this.agregarEmbtn.Name = "agregarEmbtn";
			this.agregarEmbtn.Size = new System.Drawing.Size(161, 81);
			this.agregarEmbtn.TabIndex = 1;
			this.agregarEmbtn.Text = "Agregar Empleado";
			this.agregarEmbtn.UseVisualStyleBackColor = false;
			this.agregarEmbtn.Click += new System.EventHandler(this.agregarEmbtn_Click);
			// 
			// volverBtn
			// 
			this.volverBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.volverBtn.BackColor = System.Drawing.Color.Red;
			this.volverBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.volverBtn.FlatAppearance.BorderSize = 0;
			this.volverBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.volverBtn.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.volverBtn.ForeColor = System.Drawing.Color.Black;
			this.volverBtn.Location = new System.Drawing.Point(40, 433);
			this.volverBtn.Name = "volverBtn";
			this.volverBtn.Size = new System.Drawing.Size(120, 44);
			this.volverBtn.TabIndex = 4;
			this.volverBtn.Text = "Cancelar";
			this.volverBtn.UseVisualStyleBackColor = false;
			this.volverBtn.Click += new System.EventHandler(this.volverBtn_Click);
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.tableLayoutPanel1.ColumnCount = 1;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel1.Controls.Add(this.volverBtn, 0, 3);
			this.tableLayoutPanel1.Controls.Add(this.modificarEmpBtn, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.eliminarEmpBtn, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.agregarEmbtn, 0, 0);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Right;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(644, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 4;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(200, 521);
			this.tableLayoutPanel1.TabIndex = 8;
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.tableLayoutPanel2.ColumnCount = 1;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel2.Controls.Add(this.empleadoDgv, 0, 0);
			this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 1;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(644, 521);
			this.tableLayoutPanel2.TabIndex = 9;
			// 
			// GestionarEmpleados
			// 
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(31)))));
			this.ClientSize = new System.Drawing.Size(844, 521);
			this.Controls.Add(this.tableLayoutPanel2);
			this.Controls.Add(this.tableLayoutPanel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "GestionarEmpleados";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Gestión de Empleados";
			this.Activated += new System.EventHandler(this.GestionarEmpleados_Activated);
			this.Load += new System.EventHandler(this.GestionarEmpleados_Load);
			((System.ComponentModel.ISupportInitialize)(this.empleadoDgv)).EndInit();
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel2.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button eliminarEmpBtn;
        private System.Windows.Forms.Button modificarEmpBtn;
        private System.Windows.Forms.DataGridView empleadoDgv;
        private System.Windows.Forms.Button agregarEmbtn;
        private System.Windows.Forms.Button volverBtn;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
	}
}
