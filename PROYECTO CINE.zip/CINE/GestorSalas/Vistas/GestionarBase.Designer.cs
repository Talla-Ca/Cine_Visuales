﻿namespace GestorSalas.Vistas
{
    partial class GestionarBase
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
			this.gestionarEmplBtn = new System.Windows.Forms.Button();
			this.gesPeliculaBtn = new System.Windows.Forms.Button();
			this.volverBtn = new System.Windows.Forms.Button();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// gestionarEmplBtn
			// 
			this.gestionarEmplBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.gestionarEmplBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(167)))), ((int)(((byte)(69)))));
			this.gestionarEmplBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.gestionarEmplBtn.FlatAppearance.BorderSize = 0;
			this.gestionarEmplBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.gestionarEmplBtn.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.gestionarEmplBtn.ForeColor = System.Drawing.Color.Black;
			this.gestionarEmplBtn.Location = new System.Drawing.Point(43, 181);
			this.gestionarEmplBtn.Name = "gestionarEmplBtn";
			this.gestionarEmplBtn.Size = new System.Drawing.Size(248, 66);
			this.gestionarEmplBtn.TabIndex = 1;
			this.gestionarEmplBtn.Text = "Gestionar Empleados";
			this.gestionarEmplBtn.UseVisualStyleBackColor = false;
			this.gestionarEmplBtn.Click += new System.EventHandler(this.gestionarEmplBtn_Click);
			// 
			// gesPeliculaBtn
			// 
			this.gesPeliculaBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.gesPeliculaBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(120)))), ((int)(((byte)(215)))));
			this.gesPeliculaBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.gesPeliculaBtn.FlatAppearance.BorderSize = 0;
			this.gesPeliculaBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.gesPeliculaBtn.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.gesPeliculaBtn.ForeColor = System.Drawing.Color.Black;
			this.gesPeliculaBtn.Location = new System.Drawing.Point(37, 40);
			this.gesPeliculaBtn.Name = "gesPeliculaBtn";
			this.gesPeliculaBtn.Size = new System.Drawing.Size(256, 63);
			this.gesPeliculaBtn.TabIndex = 0;
			this.gesPeliculaBtn.Text = "Gestionar Películas";
			this.gesPeliculaBtn.UseVisualStyleBackColor = false;
			this.gesPeliculaBtn.Click += new System.EventHandler(this.gesPeliculaBtn_Click);
			// 
			// volverBtn
			// 
			this.volverBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.volverBtn.BackColor = System.Drawing.Color.Red;
			this.volverBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.volverBtn.FlatAppearance.BorderSize = 0;
			this.volverBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.volverBtn.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.volverBtn.ForeColor = System.Drawing.Color.Black;
			this.volverBtn.Location = new System.Drawing.Point(93, 341);
			this.volverBtn.Name = "volverBtn";
			this.volverBtn.Size = new System.Drawing.Size(143, 40);
			this.volverBtn.TabIndex = 2;
			this.volverBtn.Text = "Volver";
			this.volverBtn.UseVisualStyleBackColor = false;
			this.volverBtn.Click += new System.EventHandler(this.volverBtn_Click);
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.tableLayoutPanel1.ColumnCount = 1;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.Controls.Add(this.volverBtn, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.gesPeliculaBtn, 0, 0);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 3;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(330, 434);
			this.tableLayoutPanel1.TabIndex = 3;
			// 
			// GestionarBase
			// 
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(31)))));
			this.ClientSize = new System.Drawing.Size(330, 434);
			this.Controls.Add(this.gestionarEmplBtn);
			this.Controls.Add(this.tableLayoutPanel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "GestionarBase";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Gestión de Recursos";
			this.tableLayoutPanel1.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button gestionarEmplBtn;
		private System.Windows.Forms.Button gesPeliculaBtn;
		private System.Windows.Forms.Button volverBtn;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
	}
}
