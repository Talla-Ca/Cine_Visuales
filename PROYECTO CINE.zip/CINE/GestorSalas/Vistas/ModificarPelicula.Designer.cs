﻿namespace GestorSalas.Vistas
{
    partial class ModificarPelicula
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.agregarPbtn = new System.Windows.Forms.Button();
			this.duracionPud = new System.Windows.Forms.NumericUpDown();
			this.generoCbx = new System.Windows.Forms.ComboBox();
			this.DuracionP = new System.Windows.Forms.Label();
			this.GeneroP = new System.Windows.Forms.Label();
			this.NombreP = new System.Windows.Forms.Label();
			this.nombrepTxb = new System.Windows.Forms.TextBox();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			((System.ComponentModel.ISupportInitialize)(this.duracionPud)).BeginInit();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// agregarPbtn
			// 
			this.agregarPbtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.agregarPbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(205)))), ((int)(((byte)(206)))));
			this.agregarPbtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.agregarPbtn.FlatAppearance.BorderSize = 0;
			this.agregarPbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.agregarPbtn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.agregarPbtn.ForeColor = System.Drawing.Color.Black;
			this.agregarPbtn.Location = new System.Drawing.Point(105, 236);
			this.agregarPbtn.Name = "agregarPbtn";
			this.agregarPbtn.Size = new System.Drawing.Size(144, 61);
			this.agregarPbtn.TabIndex = 4;
			this.agregarPbtn.Text = "Guardar Cambios";
			this.agregarPbtn.UseVisualStyleBackColor = false;
			this.agregarPbtn.Click += new System.EventHandler(this.agregarPbtn_Click);
			// 
			// duracionPud
			// 
			this.duracionPud.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.duracionPud.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(255)))));
			this.duracionPud.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.duracionPud.Location = new System.Drawing.Point(85, 158);
			this.duracionPud.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
			this.duracionPud.Name = "duracionPud";
			this.duracionPud.Size = new System.Drawing.Size(184, 29);
			this.duracionPud.TabIndex = 3;
			// 
			// generoCbx
			// 
			this.generoCbx.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.generoCbx.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(255)))));
			this.generoCbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.generoCbx.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.generoCbx.FormattingEnabled = true;
			this.generoCbx.Location = new System.Drawing.Point(85, 107);
			this.generoCbx.Name = "generoCbx";
			this.generoCbx.Size = new System.Drawing.Size(184, 29);
			this.generoCbx.TabIndex = 2;
			// 
			// DuracionP
			// 
			this.DuracionP.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.DuracionP.AutoSize = true;
			this.DuracionP.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.DuracionP.ForeColor = System.Drawing.Color.White;
			this.DuracionP.Location = new System.Drawing.Point(283, 147);
			this.DuracionP.Name = "DuracionP";
			this.DuracionP.Size = new System.Drawing.Size(101, 50);
			this.DuracionP.TabIndex = 14;
			this.DuracionP.Text = "Duración (min)";
			// 
			// GeneroP
			// 
			this.GeneroP.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.GeneroP.AutoSize = true;
			this.GeneroP.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.GeneroP.ForeColor = System.Drawing.Color.White;
			this.GeneroP.Location = new System.Drawing.Point(293, 107);
			this.GeneroP.Name = "GeneroP";
			this.GeneroP.Size = new System.Drawing.Size(80, 25);
			this.GeneroP.TabIndex = 13;
			this.GeneroP.Text = "Género";
			// 
			// NombreP
			// 
			this.NombreP.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.NombreP.AutoSize = true;
			this.NombreP.Font = new System.Drawing.Font("Segoe UI Black", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.NombreP.ForeColor = System.Drawing.Color.White;
			this.NombreP.Location = new System.Drawing.Point(289, 58);
			this.NombreP.Name = "NombreP";
			this.NombreP.Size = new System.Drawing.Size(88, 25);
			this.NombreP.TabIndex = 12;
			this.NombreP.Text = "Nombre";
			// 
			// nombrepTxb
			// 
			this.nombrepTxb.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.nombrepTxb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(255)))));
			this.nombrepTxb.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.nombrepTxb.Location = new System.Drawing.Point(85, 56);
			this.nombrepTxb.Name = "nombrepTxb";
			this.nombrepTxb.Size = new System.Drawing.Size(184, 29);
			this.nombrepTxb.TabIndex = 1;
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.tableLayoutPanel1.ColumnCount = 3;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.02564F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.97436F));
			this.tableLayoutPanel1.Controls.Add(this.duracionPud, 1, 3);
			this.tableLayoutPanel1.Controls.Add(this.generoCbx, 1, 2);
			this.tableLayoutPanel1.Controls.Add(this.nombrepTxb, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.DuracionP, 2, 3);
			this.tableLayoutPanel1.Controls.Add(this.GeneroP, 2, 2);
			this.tableLayoutPanel1.Controls.Add(this.NombreP, 2, 1);
			this.tableLayoutPanel1.Controls.Add(this.agregarPbtn, 1, 5);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 6;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.42623F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.37705F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.08197F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.34426F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.180327F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.59016F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(390, 305);
			this.tableLayoutPanel1.TabIndex = 18;
			// 
			// ModificarPelicula
			// 
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(31)))));
			this.ClientSize = new System.Drawing.Size(390, 305);
			this.Controls.Add(this.tableLayoutPanel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "ModificarPelicula";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Modificar Película";
			this.Load += new System.EventHandler(this.ModificarPelicula_Load);
			((System.ComponentModel.ISupportInitialize)(this.duracionPud)).EndInit();
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button agregarPbtn;
        private System.Windows.Forms.NumericUpDown duracionPud;
        private System.Windows.Forms.ComboBox generoCbx;
        private System.Windows.Forms.Label DuracionP;
        private System.Windows.Forms.Label GeneroP;
        private System.Windows.Forms.Label NombreP;
        private System.Windows.Forms.TextBox nombrepTxb;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
	}
}
