﻿namespace GestorSalas.Vistas
{
    partial class VentaDulces
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.panel1 = new System.Windows.Forms.Panel();
			this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.nud_coca_chica = new System.Windows.Forms.NumericUpDown();
			this.lb_inv_lata_coca = new System.Windows.Forms.Label();
			this.lb_latacoca = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.panel3 = new System.Windows.Forms.Panel();
			this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			this.lb_inv_vaso_coca = new System.Windows.Forms.Label();
			this.lb_vasococa = new System.Windows.Forms.Label();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.panel4 = new System.Windows.Forms.Panel();
			this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
			this.lb_inv_agua = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.panel5 = new System.Windows.Forms.Panel();
			this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
			this.lb_inv_palomitas_chicas = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.pictureBox5 = new System.Windows.Forms.PictureBox();
			this.panel6 = new System.Windows.Forms.Panel();
			this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
			this.lb_inv_palomitas_grandes = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.panel7 = new System.Windows.Forms.Panel();
			this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
			this.lb_inv_combo_palomitas = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.pictureBox6 = new System.Windows.Forms.PictureBox();
			this.panel8 = new System.Windows.Forms.Panel();
			this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
			this.lb_inv_hotdog = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.pictureBox9 = new System.Windows.Forms.PictureBox();
			this.panel9 = new System.Windows.Forms.Panel();
			this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
			this.lb_inv_nachos = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.pictureBox8 = new System.Windows.Forms.PictureBox();
			this.panel10 = new System.Windows.Forms.Panel();
			this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
			this.lb_inv_combo_nachos = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.pictureBox7 = new System.Windows.Forms.PictureBox();
			this.panel11 = new System.Windows.Forms.Panel();
			this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
			this.lb_inv_gomitas = new System.Windows.Forms.Label();
			this.label18 = new System.Windows.Forms.Label();
			this.pictureBox10 = new System.Windows.Forms.PictureBox();
			this.panel12 = new System.Windows.Forms.Panel();
			this.numericUpDown10 = new System.Windows.Forms.NumericUpDown();
			this.lb_inv_mms = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.pictureBox11 = new System.Windows.Forms.PictureBox();
			this.panel13 = new System.Windows.Forms.Panel();
			this.numericUpDown11 = new System.Windows.Forms.NumericUpDown();
			this.label21 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.pictureBox12 = new System.Windows.Forms.PictureBox();
			this.panel14 = new System.Windows.Forms.Panel();
			this.panel15 = new System.Windows.Forms.Panel();
			this.panel16 = new System.Windows.Forms.Panel();
			this.panel17 = new System.Windows.Forms.Panel();
			this.panel18 = new System.Windows.Forms.Panel();
			this.panel19 = new System.Windows.Forms.Panel();
			this.panel20 = new System.Windows.Forms.Panel();
			this.panel21 = new System.Windows.Forms.Panel();
			this.panel22 = new System.Windows.Forms.Panel();
			this.panel23 = new System.Windows.Forms.Panel();
			this.panel24 = new System.Windows.Forms.Panel();
			this.panel25 = new System.Windows.Forms.Panel();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.agregarPbtn = new System.Windows.Forms.Button();
			this.volverBtn = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.tableLayoutPanel2.SuspendLayout();
			this.panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.nud_coca_chica)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.panel3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			this.panel4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			this.panel5.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
			this.panel6.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
			this.panel7.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
			this.panel8.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
			this.panel9.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
			this.panel10.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
			this.panel11.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
			this.panel12.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
			this.panel13.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel1.AutoScroll = true;
			this.panel1.BackColor = System.Drawing.Color.Black;
			this.panel1.Controls.Add(this.tableLayoutPanel2);
			this.panel1.Location = new System.Drawing.Point(-3, 1);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(745, 586);
			this.panel1.TabIndex = 0;
			// 
			// tableLayoutPanel2
			// 
			this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(131)))), ((int)(((byte)(255)))));
			this.tableLayoutPanel2.ColumnCount = 3;
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
			this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
			this.tableLayoutPanel2.Controls.Add(this.panel2, 0, 0);
			this.tableLayoutPanel2.Controls.Add(this.panel3, 1, 0);
			this.tableLayoutPanel2.Controls.Add(this.panel4, 2, 0);
			this.tableLayoutPanel2.Controls.Add(this.panel5, 0, 1);
			this.tableLayoutPanel2.Controls.Add(this.panel6, 1, 1);
			this.tableLayoutPanel2.Controls.Add(this.panel7, 2, 1);
			this.tableLayoutPanel2.Controls.Add(this.panel8, 0, 2);
			this.tableLayoutPanel2.Controls.Add(this.panel9, 1, 2);
			this.tableLayoutPanel2.Controls.Add(this.panel10, 2, 2);
			this.tableLayoutPanel2.Controls.Add(this.panel11, 0, 3);
			this.tableLayoutPanel2.Controls.Add(this.panel12, 1, 3);
			this.tableLayoutPanel2.Controls.Add(this.panel13, 2, 3);
			this.tableLayoutPanel2.Controls.Add(this.panel14, 0, 4);
			this.tableLayoutPanel2.Controls.Add(this.panel15, 1, 4);
			this.tableLayoutPanel2.Controls.Add(this.panel16, 2, 4);
			this.tableLayoutPanel2.Controls.Add(this.panel17, 0, 5);
			this.tableLayoutPanel2.Controls.Add(this.panel18, 1, 5);
			this.tableLayoutPanel2.Controls.Add(this.panel19, 2, 5);
			this.tableLayoutPanel2.Controls.Add(this.panel20, 0, 6);
			this.tableLayoutPanel2.Controls.Add(this.panel21, 1, 6);
			this.tableLayoutPanel2.Controls.Add(this.panel22, 2, 6);
			this.tableLayoutPanel2.Controls.Add(this.panel23, 0, 7);
			this.tableLayoutPanel2.Controls.Add(this.panel24, 1, 7);
			this.tableLayoutPanel2.Controls.Add(this.panel25, 2, 7);
			this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
			this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel2.Name = "tableLayoutPanel2";
			this.tableLayoutPanel2.RowCount = 8;
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 300F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 300F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 300F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 300F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 300F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 300F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 300F));
			this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 300F));
			this.tableLayoutPanel2.Size = new System.Drawing.Size(728, 1296);
			this.tableLayoutPanel2.TabIndex = 0;
			// 
			// panel2
			// 
			this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel2.Controls.Add(this.nud_coca_chica);
			this.panel2.Controls.Add(this.lb_inv_lata_coca);
			this.panel2.Controls.Add(this.lb_latacoca);
			this.panel2.Controls.Add(this.pictureBox1);
			this.panel2.Location = new System.Drawing.Point(5, 5);
			this.panel2.Margin = new System.Windows.Forms.Padding(5);
			this.panel2.Name = "panel2";
			this.panel2.Padding = new System.Windows.Forms.Padding(2);
			this.panel2.Size = new System.Drawing.Size(232, 290);
			this.panel2.TabIndex = 0;
			// 
			// nud_coca_chica
			// 
			this.nud_coca_chica.Location = new System.Drawing.Point(74, 242);
			this.nud_coca_chica.Name = "nud_coca_chica";
			this.nud_coca_chica.Size = new System.Drawing.Size(91, 20);
			this.nud_coca_chica.TabIndex = 3;
			// 
			// lb_inv_lata_coca
			// 
			this.lb_inv_lata_coca.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lb_inv_lata_coca.AutoSize = true;
			this.lb_inv_lata_coca.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_inv_lata_coca.ForeColor = System.Drawing.SystemColors.Control;
			this.lb_inv_lata_coca.Location = new System.Drawing.Point(40, 195);
			this.lb_inv_lata_coca.Name = "lb_inv_lata_coca";
			this.lb_inv_lata_coca.Size = new System.Drawing.Size(171, 20);
			this.lb_inv_lata_coca.TabIndex = 2;
			this.lb_inv_lata_coca.Text = "Precio: $# - Stock: #";
			this.lb_inv_lata_coca.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lb_latacoca
			// 
			this.lb_latacoca.AutoSize = true;
			this.lb_latacoca.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_latacoca.ForeColor = System.Drawing.SystemColors.Control;
			this.lb_latacoca.Location = new System.Drawing.Point(50, 155);
			this.lb_latacoca.Name = "lb_latacoca";
			this.lb_latacoca.Size = new System.Drawing.Size(152, 20);
			this.lb_latacoca.TabIndex = 1;
			this.lb_latacoca.Text = "Lata de coca-cola";
			this.lb_latacoca.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox1.ErrorImage = null;
			this.pictureBox1.Image = global::GestorSalas.Properties.Resources.Refresco_Coca_Cola_Chico;
			this.pictureBox1.InitialImage = null;
			this.pictureBox1.Location = new System.Drawing.Point(74, 28);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Padding = new System.Windows.Forms.Padding(5);
			this.pictureBox1.Size = new System.Drawing.Size(79, 100);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
			// 
			// panel3
			// 
			this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel3.Controls.Add(this.numericUpDown1);
			this.panel3.Controls.Add(this.lb_inv_vaso_coca);
			this.panel3.Controls.Add(this.lb_vasococa);
			this.panel3.Controls.Add(this.pictureBox2);
			this.panel3.Location = new System.Drawing.Point(247, 5);
			this.panel3.Margin = new System.Windows.Forms.Padding(5);
			this.panel3.Name = "panel3";
			this.panel3.Padding = new System.Windows.Forms.Padding(2);
			this.panel3.Size = new System.Drawing.Size(232, 290);
			this.panel3.TabIndex = 1;
			// 
			// numericUpDown1
			// 
			this.numericUpDown1.Location = new System.Drawing.Point(79, 242);
			this.numericUpDown1.Name = "numericUpDown1";
			this.numericUpDown1.Size = new System.Drawing.Size(91, 20);
			this.numericUpDown1.TabIndex = 7;
			// 
			// lb_inv_vaso_coca
			// 
			this.lb_inv_vaso_coca.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lb_inv_vaso_coca.AutoSize = true;
			this.lb_inv_vaso_coca.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_inv_vaso_coca.ForeColor = System.Drawing.SystemColors.Control;
			this.lb_inv_vaso_coca.Location = new System.Drawing.Point(43, 195);
			this.lb_inv_vaso_coca.Name = "lb_inv_vaso_coca";
			this.lb_inv_vaso_coca.Size = new System.Drawing.Size(171, 20);
			this.lb_inv_vaso_coca.TabIndex = 6;
			this.lb_inv_vaso_coca.Text = "Precio: $# - Stock: #";
			this.lb_inv_vaso_coca.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lb_vasococa
			// 
			this.lb_vasococa.AutoSize = true;
			this.lb_vasococa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_vasococa.ForeColor = System.Drawing.SystemColors.Control;
			this.lb_vasococa.Location = new System.Drawing.Point(32, 155);
			this.lb_vasococa.Name = "lb_vasococa";
			this.lb_vasococa.Size = new System.Drawing.Size(199, 20);
			this.lb_vasococa.TabIndex = 5;
			this.lb_vasococa.Text = "Vaso grande Coca-Cola";
			this.lb_vasococa.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox2
			// 
			this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox2.ErrorImage = null;
			this.pictureBox2.Image = global::GestorSalas.Properties.Resources.Refresco_Coca_Cola_Grande;
			this.pictureBox2.InitialImage = null;
			this.pictureBox2.Location = new System.Drawing.Point(76, 28);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Padding = new System.Windows.Forms.Padding(5);
			this.pictureBox2.Size = new System.Drawing.Size(79, 100);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox2.TabIndex = 4;
			this.pictureBox2.TabStop = false;
			// 
			// panel4
			// 
			this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel4.Controls.Add(this.numericUpDown2);
			this.panel4.Controls.Add(this.lb_inv_agua);
			this.panel4.Controls.Add(this.label4);
			this.panel4.Controls.Add(this.pictureBox3);
			this.panel4.Location = new System.Drawing.Point(489, 5);
			this.panel4.Margin = new System.Windows.Forms.Padding(5);
			this.panel4.Name = "panel4";
			this.panel4.Padding = new System.Windows.Forms.Padding(2);
			this.panel4.Size = new System.Drawing.Size(234, 290);
			this.panel4.TabIndex = 2;
			// 
			// numericUpDown2
			// 
			this.numericUpDown2.Location = new System.Drawing.Point(80, 242);
			this.numericUpDown2.Name = "numericUpDown2";
			this.numericUpDown2.Size = new System.Drawing.Size(91, 20);
			this.numericUpDown2.TabIndex = 7;
			// 
			// lb_inv_agua
			// 
			this.lb_inv_agua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lb_inv_agua.AutoSize = true;
			this.lb_inv_agua.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_inv_agua.ForeColor = System.Drawing.SystemColors.Control;
			this.lb_inv_agua.Location = new System.Drawing.Point(46, 195);
			this.lb_inv_agua.Name = "lb_inv_agua";
			this.lb_inv_agua.Size = new System.Drawing.Size(171, 20);
			this.lb_inv_agua.TabIndex = 6;
			this.lb_inv_agua.Text = "Precio: $# - Stock: #";
			this.lb_inv_agua.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.SystemColors.Control;
			this.label4.Location = new System.Drawing.Point(76, 155);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(108, 20);
			this.label4.TabIndex = 5;
			this.label4.Text = "Agua e-pura";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox3
			// 
			this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox3.ErrorImage = null;
			this.pictureBox3.Image = global::GestorSalas.Properties.Resources.Agua_Embotellada;
			this.pictureBox3.InitialImage = null;
			this.pictureBox3.Location = new System.Drawing.Point(77, 28);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Padding = new System.Windows.Forms.Padding(5);
			this.pictureBox3.Size = new System.Drawing.Size(80, 100);
			this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox3.TabIndex = 4;
			this.pictureBox3.TabStop = false;
			// 
			// panel5
			// 
			this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel5.Controls.Add(this.numericUpDown4);
			this.panel5.Controls.Add(this.lb_inv_palomitas_chicas);
			this.panel5.Controls.Add(this.label8);
			this.panel5.Controls.Add(this.pictureBox5);
			this.panel5.Location = new System.Drawing.Point(5, 305);
			this.panel5.Margin = new System.Windows.Forms.Padding(5);
			this.panel5.Name = "panel5";
			this.panel5.Padding = new System.Windows.Forms.Padding(2);
			this.panel5.Size = new System.Drawing.Size(232, 290);
			this.panel5.TabIndex = 3;
			// 
			// numericUpDown4
			// 
			this.numericUpDown4.Location = new System.Drawing.Point(79, 242);
			this.numericUpDown4.Name = "numericUpDown4";
			this.numericUpDown4.Size = new System.Drawing.Size(91, 20);
			this.numericUpDown4.TabIndex = 7;
			// 
			// lb_inv_palomitas_chicas
			// 
			this.lb_inv_palomitas_chicas.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lb_inv_palomitas_chicas.AutoSize = true;
			this.lb_inv_palomitas_chicas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_inv_palomitas_chicas.ForeColor = System.Drawing.SystemColors.Control;
			this.lb_inv_palomitas_chicas.Location = new System.Drawing.Point(40, 195);
			this.lb_inv_palomitas_chicas.Name = "lb_inv_palomitas_chicas";
			this.lb_inv_palomitas_chicas.Size = new System.Drawing.Size(171, 20);
			this.lb_inv_palomitas_chicas.TabIndex = 6;
			this.lb_inv_palomitas_chicas.Text = "Precio: $# - Stock: #";
			this.lb_inv_palomitas_chicas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.ForeColor = System.Drawing.SystemColors.Control;
			this.label8.Location = new System.Drawing.Point(56, 155);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(146, 20);
			this.label8.TabIndex = 5;
			this.label8.Text = "Palomitas Chicas";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox5
			// 
			this.pictureBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox5.ErrorImage = null;
			this.pictureBox5.Image = global::GestorSalas.Properties.Resources.Palomitas_Mantequilla_Chicas;
			this.pictureBox5.InitialImage = null;
			this.pictureBox5.Location = new System.Drawing.Point(76, 28);
			this.pictureBox5.Name = "pictureBox5";
			this.pictureBox5.Padding = new System.Windows.Forms.Padding(5);
			this.pictureBox5.Size = new System.Drawing.Size(79, 100);
			this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox5.TabIndex = 4;
			this.pictureBox5.TabStop = false;
			// 
			// panel6
			// 
			this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel6.Controls.Add(this.numericUpDown3);
			this.panel6.Controls.Add(this.lb_inv_palomitas_grandes);
			this.panel6.Controls.Add(this.label6);
			this.panel6.Controls.Add(this.pictureBox4);
			this.panel6.Location = new System.Drawing.Point(247, 305);
			this.panel6.Margin = new System.Windows.Forms.Padding(5);
			this.panel6.Name = "panel6";
			this.panel6.Padding = new System.Windows.Forms.Padding(2);
			this.panel6.Size = new System.Drawing.Size(232, 290);
			this.panel6.TabIndex = 4;
			// 
			// numericUpDown3
			// 
			this.numericUpDown3.Location = new System.Drawing.Point(79, 242);
			this.numericUpDown3.Name = "numericUpDown3";
			this.numericUpDown3.Size = new System.Drawing.Size(91, 20);
			this.numericUpDown3.TabIndex = 7;
			// 
			// lb_inv_palomitas_grandes
			// 
			this.lb_inv_palomitas_grandes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lb_inv_palomitas_grandes.AutoSize = true;
			this.lb_inv_palomitas_grandes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_inv_palomitas_grandes.ForeColor = System.Drawing.SystemColors.Control;
			this.lb_inv_palomitas_grandes.Location = new System.Drawing.Point(43, 195);
			this.lb_inv_palomitas_grandes.Name = "lb_inv_palomitas_grandes";
			this.lb_inv_palomitas_grandes.Size = new System.Drawing.Size(171, 20);
			this.lb_inv_palomitas_grandes.TabIndex = 6;
			this.lb_inv_palomitas_grandes.Text = "Precio: $# - Stock: #";
			this.lb_inv_palomitas_grandes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.SystemColors.Control;
			this.label6.Location = new System.Drawing.Point(53, 155);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(161, 20);
			this.label6.TabIndex = 5;
			this.label6.Text = "Palomitas Grandes";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox4
			// 
			this.pictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox4.ErrorImage = null;
			this.pictureBox4.Image = global::GestorSalas.Properties.Resources.Palomitas_Mantequilla_Grandes;
			this.pictureBox4.InitialImage = null;
			this.pictureBox4.Location = new System.Drawing.Point(76, 28);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Padding = new System.Windows.Forms.Padding(5);
			this.pictureBox4.Size = new System.Drawing.Size(79, 100);
			this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox4.TabIndex = 4;
			this.pictureBox4.TabStop = false;
			// 
			// panel7
			// 
			this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel7.Controls.Add(this.numericUpDown5);
			this.panel7.Controls.Add(this.lb_inv_combo_palomitas);
			this.panel7.Controls.Add(this.label10);
			this.panel7.Controls.Add(this.pictureBox6);
			this.panel7.Location = new System.Drawing.Point(489, 305);
			this.panel7.Margin = new System.Windows.Forms.Padding(5);
			this.panel7.Name = "panel7";
			this.panel7.Padding = new System.Windows.Forms.Padding(2);
			this.panel7.Size = new System.Drawing.Size(234, 290);
			this.panel7.TabIndex = 5;
			// 
			// numericUpDown5
			// 
			this.numericUpDown5.Location = new System.Drawing.Point(80, 242);
			this.numericUpDown5.Name = "numericUpDown5";
			this.numericUpDown5.Size = new System.Drawing.Size(91, 20);
			this.numericUpDown5.TabIndex = 7;
			// 
			// lb_inv_combo_palomitas
			// 
			this.lb_inv_combo_palomitas.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lb_inv_combo_palomitas.AutoSize = true;
			this.lb_inv_combo_palomitas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_inv_combo_palomitas.ForeColor = System.Drawing.SystemColors.Control;
			this.lb_inv_combo_palomitas.Location = new System.Drawing.Point(46, 195);
			this.lb_inv_combo_palomitas.Name = "lb_inv_combo_palomitas";
			this.lb_inv_combo_palomitas.Size = new System.Drawing.Size(171, 20);
			this.lb_inv_combo_palomitas.TabIndex = 6;
			this.lb_inv_combo_palomitas.Text = "Precio: $# - Stock: #";
			this.lb_inv_combo_palomitas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.ForeColor = System.Drawing.SystemColors.Control;
			this.label10.Location = new System.Drawing.Point(27, 155);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(208, 20);
			this.label10.TabIndex = 5;
			this.label10.Text = " Combo palomitas chicas";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox6
			// 
			this.pictureBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox6.ErrorImage = null;
			this.pictureBox6.Image = global::GestorSalas.Properties.Resources.Combo_Palomitas_y_Refresco;
			this.pictureBox6.InitialImage = null;
			this.pictureBox6.Location = new System.Drawing.Point(77, 28);
			this.pictureBox6.Name = "pictureBox6";
			this.pictureBox6.Padding = new System.Windows.Forms.Padding(5);
			this.pictureBox6.Size = new System.Drawing.Size(80, 100);
			this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox6.TabIndex = 4;
			this.pictureBox6.TabStop = false;
			// 
			// panel8
			// 
			this.panel8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel8.Controls.Add(this.numericUpDown8);
			this.panel8.Controls.Add(this.lb_inv_hotdog);
			this.panel8.Controls.Add(this.label16);
			this.panel8.Controls.Add(this.pictureBox9);
			this.panel8.Location = new System.Drawing.Point(5, 605);
			this.panel8.Margin = new System.Windows.Forms.Padding(5);
			this.panel8.Name = "panel8";
			this.panel8.Padding = new System.Windows.Forms.Padding(2);
			this.panel8.Size = new System.Drawing.Size(232, 290);
			this.panel8.TabIndex = 6;
			// 
			// numericUpDown8
			// 
			this.numericUpDown8.Location = new System.Drawing.Point(79, 242);
			this.numericUpDown8.Name = "numericUpDown8";
			this.numericUpDown8.Size = new System.Drawing.Size(91, 20);
			this.numericUpDown8.TabIndex = 7;
			// 
			// lb_inv_hotdog
			// 
			this.lb_inv_hotdog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lb_inv_hotdog.AutoSize = true;
			this.lb_inv_hotdog.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_inv_hotdog.ForeColor = System.Drawing.SystemColors.Control;
			this.lb_inv_hotdog.Location = new System.Drawing.Point(40, 195);
			this.lb_inv_hotdog.Name = "lb_inv_hotdog";
			this.lb_inv_hotdog.Size = new System.Drawing.Size(171, 20);
			this.lb_inv_hotdog.TabIndex = 6;
			this.lb_inv_hotdog.Text = "Precio: $# - Stock: #";
			this.lb_inv_hotdog.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label16.ForeColor = System.Drawing.SystemColors.Control;
			this.label16.Location = new System.Drawing.Point(88, 155);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(77, 20);
			this.label16.TabIndex = 5;
			this.label16.Text = "Hot-Dog";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox9
			// 
			this.pictureBox9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox9.ErrorImage = null;
			this.pictureBox9.Image = global::GestorSalas.Properties.Resources.Hot_Dog_Clásico;
			this.pictureBox9.InitialImage = null;
			this.pictureBox9.Location = new System.Drawing.Point(76, 28);
			this.pictureBox9.Name = "pictureBox9";
			this.pictureBox9.Padding = new System.Windows.Forms.Padding(5);
			this.pictureBox9.Size = new System.Drawing.Size(79, 100);
			this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox9.TabIndex = 4;
			this.pictureBox9.TabStop = false;
			this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
			// 
			// panel9
			// 
			this.panel9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel9.Controls.Add(this.numericUpDown7);
			this.panel9.Controls.Add(this.lb_inv_nachos);
			this.panel9.Controls.Add(this.label14);
			this.panel9.Controls.Add(this.pictureBox8);
			this.panel9.Location = new System.Drawing.Point(247, 605);
			this.panel9.Margin = new System.Windows.Forms.Padding(5);
			this.panel9.Name = "panel9";
			this.panel9.Padding = new System.Windows.Forms.Padding(2);
			this.panel9.Size = new System.Drawing.Size(232, 290);
			this.panel9.TabIndex = 7;
			// 
			// numericUpDown7
			// 
			this.numericUpDown7.Location = new System.Drawing.Point(79, 242);
			this.numericUpDown7.Name = "numericUpDown7";
			this.numericUpDown7.Size = new System.Drawing.Size(91, 20);
			this.numericUpDown7.TabIndex = 7;
			// 
			// lb_inv_nachos
			// 
			this.lb_inv_nachos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lb_inv_nachos.AutoSize = true;
			this.lb_inv_nachos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_inv_nachos.ForeColor = System.Drawing.SystemColors.Control;
			this.lb_inv_nachos.Location = new System.Drawing.Point(43, 195);
			this.lb_inv_nachos.Name = "lb_inv_nachos";
			this.lb_inv_nachos.Size = new System.Drawing.Size(171, 20);
			this.lb_inv_nachos.TabIndex = 6;
			this.lb_inv_nachos.Text = "Precio: $# - Stock: #";
			this.lb_inv_nachos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.ForeColor = System.Drawing.SystemColors.Control;
			this.label14.Location = new System.Drawing.Point(57, 155);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(157, 20);
			this.label14.TabIndex = 5;
			this.label14.Text = "Nachos con queso";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox8
			// 
			this.pictureBox8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox8.ErrorImage = null;
			this.pictureBox8.Image = global::GestorSalas.Properties.Resources.Nachos_con_Queso1;
			this.pictureBox8.InitialImage = null;
			this.pictureBox8.Location = new System.Drawing.Point(76, 28);
			this.pictureBox8.Name = "pictureBox8";
			this.pictureBox8.Padding = new System.Windows.Forms.Padding(5);
			this.pictureBox8.Size = new System.Drawing.Size(79, 100);
			this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox8.TabIndex = 4;
			this.pictureBox8.TabStop = false;
			// 
			// panel10
			// 
			this.panel10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel10.Controls.Add(this.numericUpDown6);
			this.panel10.Controls.Add(this.lb_inv_combo_nachos);
			this.panel10.Controls.Add(this.label12);
			this.panel10.Controls.Add(this.pictureBox7);
			this.panel10.Location = new System.Drawing.Point(489, 605);
			this.panel10.Margin = new System.Windows.Forms.Padding(5);
			this.panel10.Name = "panel10";
			this.panel10.Padding = new System.Windows.Forms.Padding(2);
			this.panel10.Size = new System.Drawing.Size(234, 290);
			this.panel10.TabIndex = 8;
			// 
			// numericUpDown6
			// 
			this.numericUpDown6.Location = new System.Drawing.Point(80, 242);
			this.numericUpDown6.Name = "numericUpDown6";
			this.numericUpDown6.Size = new System.Drawing.Size(91, 20);
			this.numericUpDown6.TabIndex = 7;
			// 
			// lb_inv_combo_nachos
			// 
			this.lb_inv_combo_nachos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lb_inv_combo_nachos.AutoSize = true;
			this.lb_inv_combo_nachos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_inv_combo_nachos.ForeColor = System.Drawing.SystemColors.Control;
			this.lb_inv_combo_nachos.Location = new System.Drawing.Point(46, 195);
			this.lb_inv_combo_nachos.Name = "lb_inv_combo_nachos";
			this.lb_inv_combo_nachos.Size = new System.Drawing.Size(171, 20);
			this.lb_inv_combo_nachos.TabIndex = 6;
			this.lb_inv_combo_nachos.Text = "Precio: $# - Stock: #";
			this.lb_inv_combo_nachos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.ForeColor = System.Drawing.SystemColors.Control;
			this.label12.Location = new System.Drawing.Point(73, 155);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(130, 20);
			this.label12.TabIndex = 5;
			this.label12.Text = "Combo Nachos";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label12.Click += new System.EventHandler(this.label12_Click);
			// 
			// pictureBox7
			// 
			this.pictureBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox7.ErrorImage = null;
			this.pictureBox7.Image = global::GestorSalas.Properties.Resources.Combo_Nachos_y_Refresco;
			this.pictureBox7.InitialImage = null;
			this.pictureBox7.Location = new System.Drawing.Point(77, 28);
			this.pictureBox7.Name = "pictureBox7";
			this.pictureBox7.Padding = new System.Windows.Forms.Padding(5);
			this.pictureBox7.Size = new System.Drawing.Size(80, 100);
			this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox7.TabIndex = 4;
			this.pictureBox7.TabStop = false;
			// 
			// panel11
			// 
			this.panel11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel11.Controls.Add(this.numericUpDown9);
			this.panel11.Controls.Add(this.lb_inv_gomitas);
			this.panel11.Controls.Add(this.label18);
			this.panel11.Controls.Add(this.pictureBox10);
			this.panel11.Location = new System.Drawing.Point(5, 905);
			this.panel11.Margin = new System.Windows.Forms.Padding(5);
			this.panel11.Name = "panel11";
			this.panel11.Padding = new System.Windows.Forms.Padding(2);
			this.panel11.Size = new System.Drawing.Size(232, 290);
			this.panel11.TabIndex = 0;
			// 
			// numericUpDown9
			// 
			this.numericUpDown9.Location = new System.Drawing.Point(79, 242);
			this.numericUpDown9.Name = "numericUpDown9";
			this.numericUpDown9.Size = new System.Drawing.Size(91, 20);
			this.numericUpDown9.TabIndex = 7;
			// 
			// lb_inv_gomitas
			// 
			this.lb_inv_gomitas.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lb_inv_gomitas.AutoSize = true;
			this.lb_inv_gomitas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_inv_gomitas.ForeColor = System.Drawing.SystemColors.Control;
			this.lb_inv_gomitas.Location = new System.Drawing.Point(40, 195);
			this.lb_inv_gomitas.Name = "lb_inv_gomitas";
			this.lb_inv_gomitas.Size = new System.Drawing.Size(171, 20);
			this.lb_inv_gomitas.TabIndex = 6;
			this.lb_inv_gomitas.Text = "Precio: $# - Stock: #";
			this.lb_inv_gomitas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label18.ForeColor = System.Drawing.SystemColors.Control;
			this.label18.Location = new System.Drawing.Point(93, 155);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(76, 20);
			this.label18.TabIndex = 5;
			this.label18.Text = "Gomitas";
			this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox10
			// 
			this.pictureBox10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox10.ErrorImage = null;
			this.pictureBox10.Image = global::GestorSalas.Properties.Resources.Gomitas_Gusano;
			this.pictureBox10.InitialImage = null;
			this.pictureBox10.Location = new System.Drawing.Point(76, 28);
			this.pictureBox10.Name = "pictureBox10";
			this.pictureBox10.Padding = new System.Windows.Forms.Padding(5);
			this.pictureBox10.Size = new System.Drawing.Size(79, 100);
			this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox10.TabIndex = 4;
			this.pictureBox10.TabStop = false;
			// 
			// panel12
			// 
			this.panel12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel12.Controls.Add(this.numericUpDown10);
			this.panel12.Controls.Add(this.lb_inv_mms);
			this.panel12.Controls.Add(this.label20);
			this.panel12.Controls.Add(this.pictureBox11);
			this.panel12.Location = new System.Drawing.Point(247, 905);
			this.panel12.Margin = new System.Windows.Forms.Padding(5);
			this.panel12.Name = "panel12";
			this.panel12.Padding = new System.Windows.Forms.Padding(2);
			this.panel12.Size = new System.Drawing.Size(232, 290);
			this.panel12.TabIndex = 9;
			// 
			// numericUpDown10
			// 
			this.numericUpDown10.Location = new System.Drawing.Point(79, 242);
			this.numericUpDown10.Name = "numericUpDown10";
			this.numericUpDown10.Size = new System.Drawing.Size(91, 20);
			this.numericUpDown10.TabIndex = 7;
			// 
			// lb_inv_mms
			// 
			this.lb_inv_mms.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.lb_inv_mms.AutoSize = true;
			this.lb_inv_mms.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb_inv_mms.ForeColor = System.Drawing.SystemColors.Control;
			this.lb_inv_mms.Location = new System.Drawing.Point(43, 195);
			this.lb_inv_mms.Name = "lb_inv_mms";
			this.lb_inv_mms.Size = new System.Drawing.Size(171, 20);
			this.lb_inv_mms.TabIndex = 6;
			this.lb_inv_mms.Text = "Precio: $# - Stock: #";
			this.lb_inv_mms.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label20.ForeColor = System.Drawing.SystemColors.Control;
			this.label20.Location = new System.Drawing.Point(93, 155);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(56, 20);
			this.label20.TabIndex = 5;
			this.label20.Text = "MnMs";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox11
			// 
			this.pictureBox11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox11.ErrorImage = null;
			this.pictureBox11.Image = global::GestorSalas.Properties.Resources.Chocolate_M_M;
			this.pictureBox11.InitialImage = null;
			this.pictureBox11.Location = new System.Drawing.Point(76, 28);
			this.pictureBox11.Name = "pictureBox11";
			this.pictureBox11.Padding = new System.Windows.Forms.Padding(5);
			this.pictureBox11.Size = new System.Drawing.Size(79, 100);
			this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox11.TabIndex = 4;
			this.pictureBox11.TabStop = false;
			// 
			// panel13
			// 
			this.panel13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel13.Controls.Add(this.numericUpDown11);
			this.panel13.Controls.Add(this.label21);
			this.panel13.Controls.Add(this.label22);
			this.panel13.Controls.Add(this.pictureBox12);
			this.panel13.Location = new System.Drawing.Point(489, 905);
			this.panel13.Margin = new System.Windows.Forms.Padding(5);
			this.panel13.Name = "panel13";
			this.panel13.Padding = new System.Windows.Forms.Padding(2);
			this.panel13.Size = new System.Drawing.Size(234, 290);
			this.panel13.TabIndex = 10;
			// 
			// numericUpDown11
			// 
			this.numericUpDown11.Location = new System.Drawing.Point(80, 242);
			this.numericUpDown11.Name = "numericUpDown11";
			this.numericUpDown11.Size = new System.Drawing.Size(91, 20);
			this.numericUpDown11.TabIndex = 7;
			// 
			// label21
			// 
			this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.label21.AutoSize = true;
			this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label21.ForeColor = System.Drawing.SystemColors.Control;
			this.label21.Location = new System.Drawing.Point(46, 195);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(171, 20);
			this.label21.TabIndex = 6;
			this.label21.Text = "Precio: $# - Stock: #";
			this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label21.Click += new System.EventHandler(this.label21_Click);
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label22.ForeColor = System.Drawing.SystemColors.Control;
			this.label22.Location = new System.Drawing.Point(64, 155);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(122, 20);
			this.label22.TabIndex = 5;
			this.label22.Text = "Proximamente";
			this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox12
			// 
			this.pictureBox12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox12.ErrorImage = null;
			this.pictureBox12.InitialImage = null;
			this.pictureBox12.Location = new System.Drawing.Point(77, 28);
			this.pictureBox12.Name = "pictureBox12";
			this.pictureBox12.Padding = new System.Windows.Forms.Padding(5);
			this.pictureBox12.Size = new System.Drawing.Size(80, 100);
			this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox12.TabIndex = 4;
			this.pictureBox12.TabStop = false;
			// 
			// panel14
			// 
			this.panel14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel14.Location = new System.Drawing.Point(5, 1205);
			this.panel14.Margin = new System.Windows.Forms.Padding(5);
			this.panel14.Name = "panel14";
			this.panel14.Padding = new System.Windows.Forms.Padding(2);
			this.panel14.Size = new System.Drawing.Size(232, 290);
			this.panel14.TabIndex = 11;
			// 
			// panel15
			// 
			this.panel15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel15.Location = new System.Drawing.Point(247, 1205);
			this.panel15.Margin = new System.Windows.Forms.Padding(5);
			this.panel15.Name = "panel15";
			this.panel15.Padding = new System.Windows.Forms.Padding(2);
			this.panel15.Size = new System.Drawing.Size(232, 290);
			this.panel15.TabIndex = 12;
			// 
			// panel16
			// 
			this.panel16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel16.Location = new System.Drawing.Point(489, 1205);
			this.panel16.Margin = new System.Windows.Forms.Padding(5);
			this.panel16.Name = "panel16";
			this.panel16.Padding = new System.Windows.Forms.Padding(2);
			this.panel16.Size = new System.Drawing.Size(234, 290);
			this.panel16.TabIndex = 13;
			// 
			// panel17
			// 
			this.panel17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel17.Location = new System.Drawing.Point(5, 1505);
			this.panel17.Margin = new System.Windows.Forms.Padding(5);
			this.panel17.Name = "panel17";
			this.panel17.Padding = new System.Windows.Forms.Padding(2);
			this.panel17.Size = new System.Drawing.Size(232, 290);
			this.panel17.TabIndex = 14;
			// 
			// panel18
			// 
			this.panel18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel18.Location = new System.Drawing.Point(247, 1505);
			this.panel18.Margin = new System.Windows.Forms.Padding(5);
			this.panel18.Name = "panel18";
			this.panel18.Padding = new System.Windows.Forms.Padding(2);
			this.panel18.Size = new System.Drawing.Size(232, 290);
			this.panel18.TabIndex = 15;
			// 
			// panel19
			// 
			this.panel19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel19.Location = new System.Drawing.Point(489, 1505);
			this.panel19.Margin = new System.Windows.Forms.Padding(5);
			this.panel19.Name = "panel19";
			this.panel19.Padding = new System.Windows.Forms.Padding(2);
			this.panel19.Size = new System.Drawing.Size(234, 290);
			this.panel19.TabIndex = 16;
			// 
			// panel20
			// 
			this.panel20.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel20.Location = new System.Drawing.Point(5, 1805);
			this.panel20.Margin = new System.Windows.Forms.Padding(5);
			this.panel20.Name = "panel20";
			this.panel20.Padding = new System.Windows.Forms.Padding(2);
			this.panel20.Size = new System.Drawing.Size(232, 290);
			this.panel20.TabIndex = 17;
			// 
			// panel21
			// 
			this.panel21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel21.Location = new System.Drawing.Point(247, 1805);
			this.panel21.Margin = new System.Windows.Forms.Padding(5);
			this.panel21.Name = "panel21";
			this.panel21.Padding = new System.Windows.Forms.Padding(2);
			this.panel21.Size = new System.Drawing.Size(232, 290);
			this.panel21.TabIndex = 18;
			// 
			// panel22
			// 
			this.panel22.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel22.Location = new System.Drawing.Point(489, 1805);
			this.panel22.Margin = new System.Windows.Forms.Padding(5);
			this.panel22.Name = "panel22";
			this.panel22.Padding = new System.Windows.Forms.Padding(2);
			this.panel22.Size = new System.Drawing.Size(234, 290);
			this.panel22.TabIndex = 19;
			// 
			// panel23
			// 
			this.panel23.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel23.Location = new System.Drawing.Point(5, 2105);
			this.panel23.Margin = new System.Windows.Forms.Padding(5);
			this.panel23.Name = "panel23";
			this.panel23.Padding = new System.Windows.Forms.Padding(2);
			this.panel23.Size = new System.Drawing.Size(232, 290);
			this.panel23.TabIndex = 20;
			// 
			// panel24
			// 
			this.panel24.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel24.Location = new System.Drawing.Point(247, 2105);
			this.panel24.Margin = new System.Windows.Forms.Padding(5);
			this.panel24.Name = "panel24";
			this.panel24.Padding = new System.Windows.Forms.Padding(2);
			this.panel24.Size = new System.Drawing.Size(232, 290);
			this.panel24.TabIndex = 21;
			// 
			// panel25
			// 
			this.panel25.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.panel25.Location = new System.Drawing.Point(489, 2105);
			this.panel25.Margin = new System.Windows.Forms.Padding(5);
			this.panel25.Name = "panel25";
			this.panel25.Padding = new System.Windows.Forms.Padding(2);
			this.panel25.Size = new System.Drawing.Size(234, 290);
			this.panel25.TabIndex = 22;
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(16)))), ((int)(((byte)(42)))));
			this.tableLayoutPanel1.ColumnCount = 1;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel1.Controls.Add(this.agregarPbtn, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.volverBtn, 0, 3);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Right;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(748, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 4;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.36116F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 146F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.63884F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(128, 587);
			this.tableLayoutPanel1.TabIndex = 1;
			// 
			// agregarPbtn
			// 
			this.agregarPbtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.agregarPbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(167)))), ((int)(((byte)(69)))));
			this.agregarPbtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.agregarPbtn.FlatAppearance.BorderSize = 0;
			this.agregarPbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.agregarPbtn.Font = new System.Drawing.Font("Segoe UI Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.agregarPbtn.ForeColor = System.Drawing.Color.Black;
			this.agregarPbtn.Location = new System.Drawing.Point(6, 248);
			this.agregarPbtn.Name = "agregarPbtn";
			this.agregarPbtn.Size = new System.Drawing.Size(116, 91);
			this.agregarPbtn.TabIndex = 6;
			this.agregarPbtn.Text = "Comprar";
			this.agregarPbtn.UseVisualStyleBackColor = false;
			// 
			// volverBtn
			// 
			this.volverBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.volverBtn.BackColor = System.Drawing.Color.Red;
			this.volverBtn.Cursor = System.Windows.Forms.Cursors.Hand;
			this.volverBtn.FlatAppearance.BorderSize = 0;
			this.volverBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.volverBtn.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.volverBtn.ForeColor = System.Drawing.Color.Black;
			this.volverBtn.Location = new System.Drawing.Point(14, 457);
			this.volverBtn.Name = "volverBtn";
			this.volverBtn.Size = new System.Drawing.Size(99, 73);
			this.volverBtn.TabIndex = 5;
			this.volverBtn.Text = "Cancelar";
			this.volverBtn.UseVisualStyleBackColor = false;
			this.volverBtn.Click += new System.EventHandler(this.volverBtn_Click);
			// 
			// VentaDulces
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(876, 587);
			this.Controls.Add(this.tableLayoutPanel1);
			this.Controls.Add(this.panel1);
			this.Name = "VentaDulces";
			this.Text = "VentaDulces";
			this.panel1.ResumeLayout(false);
			this.tableLayoutPanel2.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.nud_coca_chica)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.panel3.ResumeLayout(false);
			this.panel3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			this.panel4.ResumeLayout(false);
			this.panel4.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			this.panel5.ResumeLayout(false);
			this.panel5.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
			this.panel6.ResumeLayout(false);
			this.panel6.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
			this.panel7.ResumeLayout(false);
			this.panel7.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
			this.panel8.ResumeLayout(false);
			this.panel8.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
			this.panel9.ResumeLayout(false);
			this.panel9.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
			this.panel10.ResumeLayout(false);
			this.panel10.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
			this.panel11.ResumeLayout(false);
			this.panel11.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
			this.panel12.ResumeLayout(false);
			this.panel12.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
			this.panel13.ResumeLayout(false);
			this.panel13.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
			this.tableLayoutPanel1.ResumeLayout(false);
			this.ResumeLayout(false);

        }

		#endregion

		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.Button volverBtn;
		private System.Windows.Forms.Button agregarPbtn;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.Panel panel9;
		private System.Windows.Forms.Panel panel10;
		private System.Windows.Forms.Panel panel11;
		private System.Windows.Forms.Panel panel12;
		private System.Windows.Forms.Panel panel13;
		private System.Windows.Forms.Panel panel14;
		private System.Windows.Forms.Panel panel15;
		private System.Windows.Forms.Panel panel16;
		private System.Windows.Forms.Panel panel17;
		private System.Windows.Forms.Panel panel18;
		private System.Windows.Forms.Panel panel19;
		private System.Windows.Forms.Panel panel20;
		private System.Windows.Forms.Panel panel21;
		private System.Windows.Forms.Panel panel22;
		private System.Windows.Forms.Panel panel23;
		private System.Windows.Forms.Panel panel24;
		private System.Windows.Forms.Panel panel25;
		private System.Windows.Forms.NumericUpDown nud_coca_chica;
		private System.Windows.Forms.Label lb_inv_lata_coca;
		private System.Windows.Forms.Label lb_latacoca;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.NumericUpDown numericUpDown1;
		private System.Windows.Forms.Label lb_inv_vaso_coca;
		private System.Windows.Forms.Label lb_vasococa;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.NumericUpDown numericUpDown2;
		private System.Windows.Forms.Label lb_inv_agua;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.NumericUpDown numericUpDown4;
		private System.Windows.Forms.Label lb_inv_palomitas_chicas;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.PictureBox pictureBox5;
		private System.Windows.Forms.NumericUpDown numericUpDown3;
		private System.Windows.Forms.Label lb_inv_palomitas_grandes;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.PictureBox pictureBox4;
		private System.Windows.Forms.NumericUpDown numericUpDown5;
		private System.Windows.Forms.Label lb_inv_combo_palomitas;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.PictureBox pictureBox6;
		private System.Windows.Forms.NumericUpDown numericUpDown8;
		private System.Windows.Forms.Label lb_inv_hotdog;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.PictureBox pictureBox9;
		private System.Windows.Forms.NumericUpDown numericUpDown7;
		private System.Windows.Forms.Label lb_inv_nachos;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.PictureBox pictureBox8;
		private System.Windows.Forms.NumericUpDown numericUpDown6;
		private System.Windows.Forms.Label lb_inv_combo_nachos;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.PictureBox pictureBox7;
		private System.Windows.Forms.NumericUpDown numericUpDown9;
		private System.Windows.Forms.Label lb_inv_gomitas;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.PictureBox pictureBox10;
		private System.Windows.Forms.NumericUpDown numericUpDown10;
		private System.Windows.Forms.Label lb_inv_mms;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.PictureBox pictureBox11;
		private System.Windows.Forms.NumericUpDown numericUpDown11;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.PictureBox pictureBox12;
	}
}